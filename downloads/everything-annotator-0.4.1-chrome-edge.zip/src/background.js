// Toolbar button, keyboard shortcuts, right-click menu and the native sidebar.
// All the real work happens in the content script and the sidebar page.

const api = globalThis.browser ?? globalThis.chrome;

const libraryUrl = api.runtime.getURL('src/library/library.html');
const openLibrary = () => api.tabs.create({ url: libraryUrl });

async function send(tab, message) {
  try {
    return await api.tabs.sendMessage(tab.id, message, { frameId: 0 });
  } catch {
    // Tabs opened before the extension was installed have no content script yet.
    const { js, css } = api.runtime.getManifest().content_scripts[0];
    await api.scripting.insertCSS({ target: { tabId: tab.id }, files: css });
    await api.scripting.executeScript({ target: { tabId: tab.id }, files: js });
    return api.tabs.sendMessage(tab.id, message, { frameId: 0 });
  }
}

// ---- Native sidebar ---------------------------------------------------------

const openSidebars = new Map(); // windowId -> port, for Chrome's side panel

api.runtime.onConnect.addListener((port) => {
  if (port.name !== 'ea-sidebar-open') return;
  port.onMessage.addListener(({ windowId }) => {
    openSidebars.set(windowId, port);
    port.onDisconnect.addListener(() => {
      if (openSidebars.get(windowId) === port) openSidebars.delete(windowId);
    });
  });
});

// These must be called straight from the click or shortcut, with no await before
// them, or the browser no longer counts it as something you asked for.
function openSidebar(tab) {
  if (api.sidePanel) return api.sidePanel.open({ windowId: tab.windowId });
  if (api.sidebarAction) return api.sidebarAction.open();
  return Promise.reject(new Error('No native sidebar here'));
}

function toggleSidebar(tab) {
  const open = openSidebars.get(tab.windowId);
  if (open) return open.postMessage({ type: 'close' });
  if (api.sidePanel) return api.sidePanel.open({ windowId: tab.windowId });
  if (api.sidebarAction) return api.sidebarAction.toggle();
  // Safari has neither. Pages the browser won't let us touch land on the library.
  return send(tab, { type: 'toggle-panel' }).catch(openLibrary);
}

// ---- Menus, button, shortcuts -----------------------------------------------

api.runtime.onInstalled.addListener(async () => {
  await api.contextMenus.removeAll();
  const menu = (id, title, contexts) => {
    try {
      api.contextMenus.create({ id, title, contexts });
    } catch (error) {
      // Browsers differ on which menu contexts exist. One missing shouldn't lose the rest.
      console.warn(`Skipped menu item ${id}:`, error);
    }
  };
  menu('highlight', 'Highlight selection', ['selection']);
  menu('note', 'Add a sticky to selection', ['selection']);
  menu('element', 'Add a sticky here', ['page', 'image', 'video', 'audio', 'link']);
  menu('library', 'All my notes', ['action']);
  api.action.setBadgeBackgroundColor({ color: '#b5651d' });
});

api.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId === 'library') return openLibrary();
  send(tab, { type: 'menu', item: info.menuItemId }).catch(() => {});
});

api.action.onClicked.addListener((tab) => {
  toggleSidebar(tab)?.catch?.(() => {});
});

api.commands.onCommand.addListener(async (command, commandTab) => {
  if (command === 'toggle-panel' && commandTab) return toggleSidebar(commandTab)?.catch?.(() => {});
  const [tab] = commandTab ? [commandTab] : await api.tabs.query({ active: true, currentWindow: true });
  if (!tab) return;
  if (command === 'toggle-panel') toggleSidebar(tab)?.catch?.(() => {});
  else send(tab, { type: command }).catch(() => {});
});

api.runtime.onMessage.addListener((message, sender, reply) => {
  if (message.type === 'open-library') openLibrary();
  if (message.type === 'badge' && sender.tab) {
    api.action.setBadgeText({ tabId: sender.tab.id, text: message.count ? String(message.count) : '' });
  }
  if (message.type === 'open-sidebar' && sender.tab) {
    let opening;
    try {
      opening = openSidebar(sender.tab);
    } catch (error) {
      opening = Promise.reject(error);
    }
    opening.then(() => reply({ opened: true }), () => reply({ opened: false }));
    return true;
  }
});
