// Turns a selection or element into a description that survives a reload, and
// finds it again later, even if the page has changed.
//
// Text is matched against a whitespace-collapsed copy of the page, because
// reformatted HTML is the most common harmless change.
(() => {
  const EA = globalThis.EA;
  const CONTEXT = 48;
  const SKIP = new Set(['SCRIPT', 'STYLE', 'NOSCRIPT', 'TEMPLATE', 'TEXTAREA']);
  const MEDIA = 'img,picture,video,canvas,svg,iframe,audio,embed,object';

  const isSpace = (c) =>
    c === 32 || (c >= 9 && c <= 13) || c === 160 || (c >= 0x2000 && c <= 0x200a) ||
    c === 0x2028 || c === 0x2029 || c === 0x202f || c === 0x3000;

  const collapse = (s) => s.replace(/\s+/g, ' ').trim();

  // ---- Page text index ----------------------------------------------------

  function buildIndex() {
    const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, {
      acceptNode: (n) => (SKIP.has(n.parentElement?.tagName) ? NodeFilter.FILTER_REJECT : NodeFilter.FILTER_ACCEPT),
    });
    const parts = [];
    const segments = [];
    let length = 0;
    let lastSpace = true;
    for (let node = walker.nextNode(); node; node = walker.nextNode()) {
      const data = node.data;
      const seg = { node, start: length, end: length, lastSpace };
      let out = '';
      for (let i = 0; i < data.length; i++) {
        if (isSpace(data.charCodeAt(i))) {
          if (!lastSpace) {
            out += ' ';
            lastSpace = true;
          }
        } else {
          out += data[i];
          lastSpace = false;
        }
      }
      length += out.length;
      seg.end = length;
      if (out) parts.push(out);
      segments.push(seg);
    }
    return { text: parts.join(''), segments };
  }

  // How many collapsed characters precede raw offset `offset` in this segment.
  function collapsedOffset(seg, offset) {
    let count = 0;
    let lastSpace = seg.lastSpace;
    const data = seg.node.data;
    for (let i = 0; i < offset && i < data.length; i++) {
      if (isSpace(data.charCodeAt(i))) {
        if (!lastSpace) count++;
        lastSpace = true;
      } else {
        count++;
        lastSpace = false;
      }
    }
    return count;
  }

  // The raw offset of the nth collapsed character in this segment.
  function rawOffset(seg, n) {
    let count = 0;
    let lastSpace = seg.lastSpace;
    const data = seg.node.data;
    for (let i = 0; i < data.length; i++) {
      const space = isSpace(data.charCodeAt(i));
      if (!space || !lastSpace) {
        if (count === n) return i;
        count++;
      }
      lastSpace = space;
    }
    return data.length;
  }

  function segmentAt(index, offset) {
    const { segments } = index;
    let lo = 0;
    let hi = segments.length - 1;
    while (lo <= hi) {
      const mid = (lo + hi) >> 1;
      const s = segments[mid];
      if (offset < s.start) hi = mid - 1;
      else if (offset >= s.end) lo = mid + 1;
      else return s;
    }
    return null;
  }

  function rangeFor(index, start, end) {
    const first = segmentAt(index, start);
    const last = segmentAt(index, end - 1);
    if (!first || !last) return null;
    const range = document.createRange();
    range.setStart(first.node, rawOffset(first, start - first.start));
    range.setEnd(last.node, rawOffset(last, end - 1 - last.start) + 1);
    return range;
  }

  // ---- Describing a selection ---------------------------------------------

  function describeRange(range, index = buildIndex()) {
    let start = null;
    let end = null;
    for (const seg of index.segments) {
      if (seg.end === seg.start || !range.intersectsNode(seg.node)) continue;
      const s = seg.node === range.startContainer ? seg.start + collapsedOffset(seg, range.startOffset) : seg.start;
      const e = seg.node === range.endContainer ? seg.start + collapsedOffset(seg, range.endOffset) : seg.end;
      if (e > s) {
        start ??= s;
        end = e;
      }
    }
    if (start === null) return null;
    const { text } = index;
    while (start < end && text[start] === ' ') start++;
    while (end > start && text[end - 1] === ' ') end--;
    if (start === end) return null;
    return {
      kind: 'text',
      exact: text.slice(start, end),
      prefix: text.slice(Math.max(0, start - CONTEXT), start),
      suffix: text.slice(end, end + CONTEXT),
      start,
    };
  }

  // ---- Finding text again -------------------------------------------------

  function sharedTail(a, b) {
    let n = 0;
    while (n < a.length && n < b.length && a[a.length - 1 - n] === b[b.length - 1 - n]) n++;
    return n;
  }

  function sharedHead(a, b) {
    let n = 0;
    while (n < a.length && n < b.length && a[n] === b[n]) n++;
    return n;
  }

  function occurrences(text, needle, limit = 500) {
    const hits = [];
    for (let i = text.indexOf(needle); i >= 0 && hits.length < limit; i = text.indexOf(needle, i + 1)) hits.push(i);
    return hits;
  }

  // Dice coefficient over character pairs: 1 is identical, 0 shares nothing.
  function similarity(a, b) {
    a = a.slice(0, 3000);
    b = b.slice(0, 3000);
    if (a === b) return 1;
    if (a.length < 2 || b.length < 2) return 0;
    const pairs = new Map();
    for (let i = 0; i < a.length - 1; i++) {
      const p = a.slice(i, i + 2);
      pairs.set(p, (pairs.get(p) || 0) + 1);
    }
    let shared = 0;
    for (let i = 0; i < b.length - 1; i++) {
      const p = b.slice(i, i + 2);
      const n = pairs.get(p);
      if (n) {
        pairs.set(p, n - 1);
        shared++;
      }
    }
    return (2 * shared) / (a.length + b.length - 2);
  }

  function contextScore(text, start, end, anchor) {
    const before = text.slice(Math.max(0, start - CONTEXT), start);
    const after = text.slice(end, end + CONTEXT);
    return sharedTail(before, anchor.prefix) + sharedHead(after, anchor.suffix);
  }

  function findExact(text, anchor) {
    const { exact } = anchor;
    let best = null;
    for (const start of occurrences(text, exact)) {
      const context = contextScore(text, start, start + exact.length, anchor);
      const nearness = 1 - Math.min(1, Math.abs(start - anchor.start) / (text.length || 1));
      const score = context + nearness * 8;
      if (!best || score > best.score) best = { start, end: start + exact.length, score, context };
    }
    if (!best) return null;
    // A short phrase with none of its old surroundings is probably a different
    // occurrence altogether. Better to admit it's lost than mark the wrong words.
    const hadContext = anchor.prefix || anchor.suffix;
    if (exact.length < 16 && hadContext && best.context < 4) return null;
    return best;
  }

  // The passage was edited: look for its opening and closing words.
  function findByEnds(text, anchor) {
    const { exact } = anchor;
    if (exact.length < 20) return null;
    const k = Math.min(16, Math.floor(exact.length / 3));
    const head = exact.slice(0, k);
    const tail = exact.slice(-k);
    const len = exact.length;
    const candidates = [];
    const heads = occurrences(text, head, 100);
    const tails = occurrences(text, tail, 100);
    for (const h of heads) {
      candidates.push([h, h + len]);
      for (const t of tails) {
        const span = t + k - h;
        if (span >= len * 0.5 && span <= len * 1.6) candidates.push([h, t + k]);
      }
    }
    for (const t of tails) candidates.push([t + k - len, t + k]);
    let best = null;
    for (const [start, end] of candidates) {
      if (start < 0 || end > text.length) continue;
      const score = similarity(text.slice(start, end), exact);
      if (score >= 0.6 && (!best || score > best.score)) best = { start, end, score };
    }
    return best;
  }

  // The words themselves changed, but what's on either side of them didn't.
  function findBetweenContext(text, anchor) {
    const before = anchor.prefix.slice(-24);
    const after = anchor.suffix.slice(0, 24);
    if (before.length < 8 || after.length < 8) return null;
    const maxGap = anchor.exact.length * 2 + 30;
    for (const p of occurrences(text, before, 100)) {
      const start = p + before.length;
      const end = text.indexOf(after, start);
      if (end > start && end - start <= maxGap) return { start, end };
    }
    return null;
  }

  function resolveText(anchor, index) {
    const { text } = index;
    const exact = findExact(text, anchor);
    const hit = exact || findByEnds(text, anchor) || findBetweenContext(text, anchor);
    if (!hit) return null;
    const range = rangeFor(index, hit.start, hit.end);
    if (!range) return null;
    return {
      status: exact ? 'anchored' : 'changed',
      range,
      current: text.slice(hit.start, hit.end),
      raw: collapse(range.toString()),
    };
  }

  // ---- Words and sentences under the pointer ------------------------------

  function caretAt(x, y) {
    if (document.caretPositionFromPoint) {
      const c = document.caretPositionFromPoint(x, y);
      return c && { node: c.offsetNode, offset: c.offset };
    }
    const r = document.caretRangeFromPoint?.(x, y);
    return r && { node: r.startContainer, offset: r.startOffset };
  }

  function blockOf(node) {
    let el = node.parentElement;
    while (el.parentElement && getComputedStyle(el).display.startsWith('inline')) el = el.parentElement;
    return el;
  }

  function pointIn(range, x, y) {
    for (const r of range.getClientRects()) {
      if (x >= r.left && x <= r.right && y >= r.top && y <= r.bottom) return true;
    }
    return false;
  }

  // The word or sentence at a screen position, or null if that isn't over text.
  // Sentences can run across links and bold, so this works on the whole block.
  function textUnitAt(x, y, unit) {
    const caret = caretAt(x, y);
    if (!caret || caret.node.nodeType !== Node.TEXT_NODE) return null;
    const parent = caret.node.parentElement;
    if (!parent || SKIP.has(parent.tagName) || parent.isContentEditable || parent.closest('input,select,button')) return null;

    const block = blockOf(caret.node);
    const walker = document.createTreeWalker(block, NodeFilter.SHOW_TEXT, {
      acceptNode: (n) => (SKIP.has(n.parentElement?.tagName) ? NodeFilter.FILTER_REJECT : NodeFilter.FILTER_ACCEPT),
    });
    const nodes = [];
    let text = '';
    let at = -1;
    for (let n = walker.nextNode(); n; n = walker.nextNode()) {
      if (n === caret.node) at = text.length + caret.offset;
      nodes.push({ node: n, start: text.length });
      text += n.data;
      if (text.length > 200000) return null;
    }
    if (at < 0 || !text.trim()) return null;

    const segments = new Intl.Segmenter(undefined, { granularity: unit }).segment(text);
    const seg = segments.containing(Math.min(at, text.length - 1));
    if (!seg || (unit === 'word' && !seg.isWordLike)) return null;
    const trimmed = seg.segment.trimEnd();
    const start = seg.index + (trimmed.length - trimmed.trimStart().length);
    const end = seg.index + trimmed.length;
    if (end <= start) return null;

    const locate = (offset, isEnd) => {
      for (let i = nodes.length - 1; i >= 0; i--) {
        const { node, start: s } = nodes[i];
        if (isEnd ? s < offset : s <= offset) return { node, offset: offset - s };
      }
      return null;
    };
    const from = locate(start, false);
    const to = locate(end, true);
    if (!from || !to) return null;
    const range = document.createRange();
    range.setStart(from.node, from.offset);
    range.setEnd(to.node, to.offset);
    return pointIn(range, x, y) ? range : null;
  }

  // ---- Elements -----------------------------------------------------------

  const area = (r) => r.width * r.height;

  // Images, video and friends have no text to select, so a note goes on the box
  // around them. That box is skipped if it's really a whole page section.
  function promoteElement(target) {
    let el = target;
    if (el instanceof SVGElement) el = el.ownerSVGElement ? el.closest('svg') : el;
    if (!el.matches(MEDIA)) return el;
    const parent = el.parentElement?.closest('figure,picture,div,section,article,li,td');
    if (!parent || parent === document.body) return el;
    const mine = area(el.getBoundingClientRect());
    const theirs = area(parent.getBoundingClientRect());
    const screen = innerWidth * innerHeight;
    return theirs <= Math.max(mine * 4, 40000) && theirs < screen * 0.8 ? parent : el;
  }

  const stableId = (id) =>
    /^[A-Za-z][\w-]*$/.test(id) && !/\d{4,}/.test(id) && !/^(ember|react|radix|headlessui|mui)/i.test(id);

  function cssPath(el) {
    const parts = [];
    for (let cur = el; cur && cur !== document.documentElement; cur = cur.parentElement) {
      if (cur.id && stableId(cur.id) && document.querySelectorAll(`#${CSS.escape(cur.id)}`).length === 1) {
        parts.unshift(`#${CSS.escape(cur.id)}`);
        break;
      }
      if (cur === document.body) {
        parts.unshift('body');
        break;
      }
      const tag = cur.localName;
      let nth = 1;
      for (let s = cur.previousElementSibling; s; s = s.previousElementSibling) if (s.localName === tag) nth++;
      parts.unshift(`${CSS.escape(tag)}:nth-of-type(${nth})`);
    }
    return parts.join(' > ');
  }

  function mediaOf(el) {
    const m = el.matches('img,video,audio,source,embed') ? el : el.querySelector('img,video');
    if (!m) return { src: '', alt: '' };
    const src = m.currentSrc || m.src || '';
    return { src: src.startsWith('data:') ? '' : src.slice(0, 1000), alt: (m.alt || '').slice(0, 300) };
  }

  const elementText = (el) => collapse(el.textContent || '').slice(0, 200);

  function describeElement(el) {
    return { kind: 'element', selector: cssPath(el), tag: el.localName, text: elementText(el), ...mediaOf(el) };
  }

  const fileName = (src) => {
    try {
      return new URL(src).pathname.split('/').pop();
    } catch {
      return src;
    }
  };

  const sameMedia = (a, b) =>
    (a.src && b.src && (a.src === b.src || fileName(a.src) === fileName(b.src))) || (a.alt && a.alt === b.alt);

  function looksLike(el, anchor) {
    if (el.localName !== anchor.tag) return false;
    if (anchor.src || anchor.alt) return Boolean(sameMedia(anchor, mediaOf(el)));
    if (anchor.text) return similarity(elementText(el), anchor.text) >= 0.6;
    return true;
  }

  function findMoved(anchor) {
    if (anchor.src || anchor.alt) {
      for (const m of document.querySelectorAll('img,video')) {
        if (!sameMedia(anchor, mediaOf(m))) continue;
        for (let up = m, i = 0; up && i < 6; up = up.parentElement, i++) {
          if (up.localName === anchor.tag) return up;
        }
      }
      return null;
    }
    if (anchor.text.length < 12) return null;
    let found = null;
    let best = 0.8;
    const all = document.getElementsByTagName(anchor.tag);
    for (let i = 0; i < all.length && i < 5000; i++) {
      const score = similarity(elementText(all[i]), anchor.text);
      if (score > best) {
        best = score;
        found = all[i];
      }
    }
    return found;
  }

  function resolveElement(anchor) {
    let el = null;
    try {
      el = document.querySelector(anchor.selector);
    } catch {} // a selector from a shared file may not parse
    if (el && looksLike(el, anchor)) return { status: 'anchored', el };
    const moved = findMoved(anchor);
    return moved ? { status: 'anchored', el: moved } : null;
  }

  EA.anchoring = { buildIndex, describeRange, resolveText, describeElement, resolveElement, promoteElement, textUnitAt, collapse };
})();
