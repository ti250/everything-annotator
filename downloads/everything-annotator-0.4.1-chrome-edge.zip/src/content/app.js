// Ties it together: owns the page's annotations, keeps them attached as the
// page changes, and saves them.
(() => {
  const EA = globalThis.EA;
  if (globalThis.__eaStarted || window !== window.top || !document.body) return;
  globalThis.__eaStarted = true;

  const { el, anchoring, api } = EA;
  const SETTLE_MS = 1500; // pages that render late get this long before anything counts as lost
  const ORPHAN_RETRY_MS = 4000;

  // ---- Host element -------------------------------------------------------

  const host = document.createElement('ea-root');
  const shadow = host.attachShadow({ mode: EA.SHADOW_MODE });
  EA.applyStyles(shadow, EA.UI_CSS);
  const layer = el('div', { class: 'layer' });
  const fixed = el('div', { class: 'fixed' });
  const toastBox = el('div', { class: 'toasts', 'aria-live': 'polite' });
  fixed.append(toastBox);
  shadow.append(layer, fixed);
  document.documentElement.append(host);

  // A closed root keeps notes away from page scripts, but it also means Vimium,
  // and sites with keyboard shortcuts, see focus land on a plain <ea-root> and
  // treat typing as commands. Looking editable while a field has focus fixes the
  // tools that check; stopping key events on the way out fixes the page's own.
  const isField = (node) => node.matches?.('textarea,input');
  shadow.addEventListener('focusin', (e) => {
    if (isField(e.target)) host.setAttribute('contenteditable', 'true');
  });
  shadow.addEventListener('focusout', () => host.removeAttribute('contenteditable'));
  for (const type of ['keydown', 'keypress', 'keyup']) {
    shadow.addEventListener(type, (e) => {
      if (!isField(e.target)) return;
      e.stopPropagation();
      if (type === 'keydown' && e.key === 'Escape') e.target.blur();
    });
  }

  const ui = {
    host,
    layer,
    fixed,
    owns: (e) => e.composedPath().includes(host),
    focused: () => shadow.activeElement,
  };

  function toast(message, action) {
    const node = el('div', { class: 'toast' }, el('span', { text: message }));
    const dismiss = () => node.remove();
    if (action) {
      node.append(
        el('button', {
          class: 'toast-action',
          type: 'button',
          text: action.label,
          onclick: () => {
            dismiss();
            action.run();
          },
        })
      );
    }
    toastBox.append(node);
    setTimeout(dismiss, action ? 7000 : 4000);
  }

  // ---- State --------------------------------------------------------------

  const anns = new Map();
  const live = new Map(); // id -> { status, range?, el?, current?, raw? }
  const unsaved = new Map(); // id -> debounce timer
  const inFlight = new Set();
  let url = EA.pageUrl(location.href);
  let settings = { ...EA.DEFAULT_SETTINGS };
  let settled = false;
  let panelOpen = false;
  let activeId = null;
  let hoverId = null;
  let lastOrphanTry = 0;
  let lastBadge = -1;
  let context = null; // where the last right-click happened
  let sidebarPort = null; // set while the native sidebar is showing this tab
  let pendingFocus = null;

  const highlights = Object.fromEntries(EA.COLORS.map((c) => [c, new Highlight()]));
  for (const [color, h] of Object.entries(highlights)) CSS.highlights.set(`ea-${color}`, h);
  const activeHighlight = new Highlight();
  activeHighlight.priority = 10;
  CSS.highlights.set('ea-active', activeHighlight);
  const markedElements = new Set();

  // ---- Saving -------------------------------------------------------------

  function saveFailed(error) {
    console.error('Everything Annotator could not save:', error);
    // After an extension update, scripts left on open pages lose their storage access.
    toast("Couldn't save that note. Reload this page and try again.");
  }

  function save(id) {
    clearTimeout(unsaved.get(id));
    unsaved.delete(id);
    const ann = anns.get(id);
    if (!ann) return;
    inFlight.add(id);
    try {
      EA.store.put(url, document.title, ann).catch(saveFailed).finally(() => inFlight.delete(id));
    } catch (error) {
      inFlight.delete(id);
      saveFailed(error);
    }
  }

  function flush() {
    for (const id of [...unsaved.keys()]) save(id);
  }

  // ---- Anchors ------------------------------------------------------------

  function isHealthy(ann) {
    const l = live.get(ann.id);
    if (!l) return false;
    if (l.status === 'orphan' || l.status === 'pending') return false;
    if (l.el) return l.el.isConnected;
    const { range } = l;
    return !range.collapsed && range.startContainer.isConnected && anchoring.collapse(range.toString()) === l.raw;
  }

  function resolve(list) {
    if (!list.length) return;
    const index = list.some((a) => a.anchor.kind === 'text') ? anchoring.buildIndex() : null;
    for (const ann of list) {
      const found = ann.anchor.kind === 'text' ? anchoring.resolveText(ann.anchor, index) : anchoring.resolveElement(ann.anchor);
      live.set(ann.id, found || { status: settled ? 'orphan' : 'pending' });
    }
  }

  function applyMarks() {
    for (const h of Object.values(highlights)) h.clear();
    activeHighlight.clear();
    for (const node of markedElements) {
      node.removeAttribute('data-ea-el');
      node.removeAttribute('data-ea-active');
    }
    markedElements.clear();
    const lit = hoverId || activeId;
    for (const ann of anns.values()) {
      const l = live.get(ann.id);
      if (l?.range) {
        highlights[ann.color].add(l.range);
        if (ann.id === lit) activeHighlight.add(l.range);
      } else if (l?.el) {
        l.el.setAttribute('data-ea-el', ann.color);
        if (ann.id === lit) l.el.setAttribute('data-ea-active', '');
        markedElements.add(l.el);
      }
    }
  }

  // Null when the anchor isn't currently visible on the page.
  function anchorBox(id) {
    const l = live.get(id);
    if (l?.el) {
      const r = l.el.getBoundingClientRect();
      return r.width || r.height ? { first: r, block: r } : null;
    }
    if (!l?.range) return null;
    const first = [...l.range.getClientRects()].find((r) => r.width > 0);
    if (!first) return null;
    let block = l.range.commonAncestorContainer;
    if (block.nodeType !== 1) block = block.parentElement;
    while (block.parentElement && getComputedStyle(block).display.startsWith('inline')) block = block.parentElement;
    return { first, block: block.getBoundingClientRect() };
  }

  const pageY = (id) => {
    const box = anchorBox(id);
    return box ? box.first.top + scrollY : Infinity;
  };

  // ---- Rendering ----------------------------------------------------------

  let notes;
  let panel;
  let picker;
  let selectionBar;

  function sendBadge() {
    if (anns.size === lastBadge) return;
    lastBadge = anns.size;
    try {
      api.runtime.sendMessage({ type: 'badge', count: anns.size })?.catch?.(() => {});
    } catch {}
  }

  // Everything the native sidebar needs in order to draw the sidebar.
  function snapshot() {
    const items = [...anns.values()].map((ann) => ({
      ann,
      status: live.get(ann.id)?.status || 'pending',
      current: live.get(ann.id)?.current,
      hidden: !anchorBox(ann.id),
    }));
    const { placed, lost } = EA.app.groups();
    return {
      url,
      title: document.title,
      items,
      placed: placed.map((a) => a.id),
      lost: lost.map((a) => a.id),
      activeId,
    };
  }

  function postToSidebar(message) {
    try {
      sidebarPort?.postMessage(message);
    } catch {
      sidebarPort = null;
    }
  }

  function render({ marks = true } = {}) {
    if (marks) applyMarks();
    document.documentElement.toggleAttribute('data-ea-panel', panelOpen);
    notes.sync();
    panel.sync();
    notes.layout();
    sendBadge();
    if (sidebarPort) postToSidebar({ type: 'state', state: snapshot() });
  }

  let layoutQueued = false;
  function queueLayout() {
    if (layoutQueued) return;
    layoutQueued = true;
    requestAnimationFrame(() => {
      layoutQueued = false;
      notes.layout();
    });
  }

  function openNote(id) {
    render();
    if (settings.postits && notes.focus(id)) return;
    focusInPanel(id);
  }

  async function focusInPanel(id) {
    if (sidebarPort) return postToSidebar({ type: 'focus', id });
    pendingFocus = id;
    await togglePanel(true);
    if (panelOpen) {
      pendingFocus = null;
      panel.focus(id);
    }
  }

  // ---- Changing annotations -----------------------------------------------

  function add(anchor, color, withNote, found) {
    const now = new Date().toISOString();
    const ann = {
      id: EA.uid(),
      type: anchor.kind,
      color,
      note: '',
      createdAt: now,
      updatedAt: now,
      anchor,
      pos: { dx: 0, dy: 0 },
      collapsed: false,
    };
    anns.set(ann.id, ann);
    live.set(ann.id, found);
    save(ann.id);
    if (withNote) {
      activeId = ann.id;
      openNote(ann.id);
    } else {
      render();
    }
  }

  function createFromRange(range, color, withNote) {
    const index = anchoring.buildIndex();
    const anchor = anchoring.describeRange(range, index);
    if (!anchor) return toast("Couldn't highlight that selection.");
    const found = anchoring.resolveText(anchor, index);
    if (!found) return toast("Couldn't highlight that selection.");
    if (color !== settings.color) updateSettings({ color });
    add(anchor, color, withNote, found);
  }

  function createFromElement(element) {
    add(anchoring.describeElement(element), settings.color, true, { status: 'anchored', el: element });
  }

  function touch(ann, fields) {
    Object.assign(ann, fields, { updatedAt: new Date().toISOString() });
  }

  function patch(id, fields) {
    const ann = anns.get(id);
    if (!ann) return;
    touch(ann, fields);
    save(id);
    render();
  }

  function typeNote(id, text) {
    const ann = anns.get(id);
    if (!ann) return;
    touch(ann, { note: text });
    clearTimeout(unsaved.get(id));
    unsaved.set(id, setTimeout(() => save(id), 300));
    render({ marks: false });
  }

  function remove(id) {
    const ann = anns.get(id);
    if (!ann) return;
    clearTimeout(unsaved.get(id));
    unsaved.delete(id);
    anns.delete(id);
    const was = live.get(id);
    live.delete(id);
    if (activeId === id) activeId = null;
    if (hoverId === id) hoverId = null;
    EA.store.remove(url, document.title, id).catch(saveFailed);
    render();
    toast('Note thrown away.', {
      label: 'Undo',
      run: () => {
        anns.set(id, ann);
        live.set(id, was);
        save(id);
        render();
      },
    });
  }

  function setActive(id) {
    if (activeId === id) return;
    activeId = id;
    render();
  }

  function setHover(id) {
    if (hoverId === id) return;
    hoverId = id;
    applyMarks();
    notes.layout();
  }

  function jumpTo(id) {
    const l = live.get(id);
    const target = l?.el || l?.range?.startContainer.parentElement;
    if (!target) return;
    target.scrollIntoView({ block: 'center', behavior: matchMedia('(prefers-reduced-motion: reduce)').matches ? 'auto' : 'smooth' });
    setActive(id);
  }

  function startReattach(id) {
    picker.start({
      label: 'Click or drag over what this note belongs to. ↓ one word, ↑ something bigger. Esc cancels.',
      allowText: true,
      onPick: ({ range, element }) => {
        const ann = anns.get(id);
        if (!ann) return;
        let anchor;
        let found;
        if (range) {
          const index = anchoring.buildIndex();
          anchor = anchoring.describeRange(range, index);
          found = anchor && anchoring.resolveText(anchor, index);
        } else {
          anchor = anchoring.describeElement(element);
          found = { status: 'anchored', el: element };
        }
        if (!found) return toast("Couldn't attach to that. Try again.");
        live.set(id, found);
        patch(id, { anchor, type: anchor.kind, pos: { dx: 0, dy: 0 } });
        toast('Stuck back on.');
      },
    });
  }

  function startPick() {
    selectionBar.hide();
    picker.start({
      label: 'Click to add a sticky here. ↓ one word, ↑ something bigger, drag for exact text. Esc cancels.',
      allowText: true,
      onPick: ({ range, element }) => (range ? createFromRange(range, settings.color, true) : createFromElement(element)),
    });
  }

  // ---- Files --------------------------------------------------------------

  function sharePage() {
    flush();
    const page = { url, title: document.title, annotations: [...anns.values()] };
    if (!page.annotations.length) return toast('No notes on this page to save yet.');
    EA.showShareDialog(fixed, page);
  }

  async function importText(text) {
    let pages;
    try {
      pages = EA.parseFile(text);
    } catch (error) {
      return toast(error.message);
    }
    const { added, updated } = await EA.store.importPages(pages);
    const elsewhere = pages.find((p) => p.url !== url);
    const count = `${added} new, ${updated} updated`;
    if (elsewhere && EA.isOpenableUrl(elsewhere.url) && pages.length === 1) {
      toast(`Saved (${count}). Those notes belong to another page.`, {
        label: 'Open it',
        run: () => window.open(elsewhere.url, '_blank', 'noopener'),
      });
    } else {
      toast(`Notes imported (${count}).`);
    }
  }

  // ---- Settings -----------------------------------------------------------

  function updateSettings(change) {
    settings = { ...settings, ...change };
    EA.store.setSettings(settings).catch(saveFailed);
    render({ marks: false });
  }

  function showInPagePanel(open) {
    panelOpen = open;
    if (settings.panelOpen !== open) updateSettings({ panelOpen: open });
    else render({ marks: false });
  }

  // The native sidebar is best, since the browser really resizes the page. Safari
  // doesn't have one, and Firefox only opens it from the toolbar button or a
  // shortcut, so those fall back to the sidebar inside the page.
  async function togglePanel(open = !(panelOpen || sidebarPort)) {
    if (!open) return showInPagePanel(false);
    if (sidebarPort || panelOpen) return;
    let opened = false;
    try {
      opened = (await api.runtime.sendMessage({ type: 'open-sidebar' }))?.opened;
    } catch {}
    if (!opened) showInPagePanel(true);
  }

  // ---- Keeping up with the page -------------------------------------------

  async function load() {
    flush();
    anns.clear();
    live.clear();
    activeId = null;
    hoverId = null;
    settled = false;
    const loadingUrl = url;
    const page = await EA.store.getPage(url);
    if (loadingUrl !== url) return;
    for (const a of page.annotations) anns.set(a.id, a);
    resolve([...anns.values()]);
    if (settings.panelOpen && anns.size) panelOpen = true;
    render();
    setTimeout(() => {
      if (loadingUrl !== url) return;
      settled = true;
      refresh(true);
      for (const [id, l] of live) if (l.status === 'pending') live.set(id, { status: 'orphan' });
      render();
    }, SETTLE_MS);
  }

  function refresh(force) {
    const now = Date.now();
    const retryOrphans = force || now - lastOrphanTry > ORPHAN_RETRY_MS;
    const stale = [...anns.values()].filter((a) => {
      if (isHealthy(a)) return false;
      return live.get(a.id)?.status !== 'orphan' || retryOrphans;
    });
    if (stale.length) {
      if (retryOrphans) lastOrphanTry = now;
      resolve(stale);
      render();
    } else {
      queueLayout();
    }
  }

  function checkUrl() {
    const next = EA.pageUrl(location.href);
    if (next === url) return false;
    url = next;
    load();
    return true;
  }

  let passTimer = null;
  function schedulePass() {
    passTimer ??= setTimeout(() => {
      passTimer = null;
      if (!checkUrl()) refresh(false);
    }, 500);
  }

  function hitTest(x, y, target) {
    for (const ann of anns.values()) {
      const l = live.get(ann.id);
      if (!l?.range) continue;
      for (const r of l.range.getClientRects()) {
        if (x >= r.left && x <= r.right && y >= r.top && y <= r.bottom) return ann.id;
      }
    }
    const marked = target.closest?.('[data-ea-el]');
    if (marked) for (const [id, l] of live) if (l.el === marked) return id;
    return null;
  }

  function onPageClick(e) {
    if (ui.owns(e) || picker.active || !getSelection().isCollapsed) return;
    const id = hitTest(e.clientX, e.clientY, e.target);
    if (id === activeId) return;
    if (!id) return setActive(null);
    activeId = id;
    const ann = anns.get(id);
    render();
    if (!settings.postits) {
      focusInPanel(id);
    } else if (!ann.note.trim()) {
      notes.focus(id);
    } else if (panelOpen) {
      panel.reveal(id);
    }
  }

  function onMenu(item) {
    const sel = getSelection();
    if (item === 'element') {
      if (!context?.target.isConnected) return toast("Can't add a sticky there. Embedded frames aren't supported yet.");
      const sentence = anchoring.textUnitAt(context.x, context.y, 'sentence');
      if (sentence) return createFromRange(sentence, settings.color, true);
      return createFromElement(anchoring.promoteElement(context.target));
    }
    if (sel.isCollapsed) return toast("Can't reach that selection. Embedded frames aren't supported yet.");
    const range = sel.getRangeAt(0).cloneRange();
    selectionBar.hide();
    sel.removeAllRanges();
    createFromRange(range, settings.color, item === 'note');
  }

  function handleMessage(message) {
    if (message.type === 'toggle-panel') togglePanel();
    else if (message.type === 'toggle-postits') updateSettings({ postits: !settings.postits });
    else if (message.type === 'start-pick') startPick();
    else if (message.type === 'menu') onMenu(message.item);
  }

  function onSidebarConnect(port) {
    if (port.name !== 'ea-sidebar') return;
    if (panelOpen) showInPagePanel(false);
    sidebarPort = port;
    port.onDisconnect.addListener(() => {
      if (sidebarPort === port) sidebarPort = null;
      render({ marks: false });
    });
    port.onMessage.addListener(({ action, args = [] }) => {
      if (action === 'importText') importText(...args);
      else if (SIDEBAR_ACTIONS.has(action)) EA.app[action](...args);
    });
    render({ marks: false });
    if (pendingFocus) {
      postToSidebar({ type: 'focus', id: pendingFocus });
      pendingFocus = null;
    }
  }

  function onStorageChange(changes, area) {
    if (area !== 'local') return;
    if (changes.settings?.newValue) {
      settings = { ...settings, ...changes.settings.newValue };
      render({ marks: false });
    }
    const change = changes[EA.pageKey(url)];
    if (!change) return;
    // Another tab, the library or an import changed this page. Pick up whatever
    // is newer, without disturbing a note that's being typed here.
    const incoming = change.newValue?.annotations || [];
    const ids = new Set(incoming.map((a) => a.id));
    const fresh = [];
    let changed = false;
    for (const a of incoming) {
      const mine = anns.get(a.id);
      if (unsaved.has(a.id) || (mine && a.updatedAt <= mine.updatedAt)) continue;
      anns.set(a.id, a);
      changed = true;
      if (!mine || JSON.stringify(mine.anchor) !== JSON.stringify(a.anchor)) fresh.push(a);
    }
    for (const id of [...anns.keys()]) {
      if (ids.has(id) || unsaved.has(id) || inFlight.has(id)) continue;
      anns.delete(id);
      live.delete(id);
      changed = true;
    }
    if (!changed) return;
    resolve(fresh);
    for (const a of fresh) if (live.get(a.id)?.status === 'pending' && settled) live.set(a.id, { status: 'orphan' });
    render();
  }

  // ---- Start --------------------------------------------------------------

  const SIDEBAR_ACTIONS = new Set(['typeNote', 'flush', 'remove', 'setColor', 'setHover', 'jumpTo', 'startPick', 'startReattach']);

  EA.app = {
    get settings() { return settings; },
    get panelOpen() { return panelOpen; },
    get activeId() { return activeId; },
    get hoverId() { return hoverId; },
    get picking() { return picker.active; },
    get: (id) => anns.get(id),
    annotations: () => [...anns.values()],
    liveOf: (id) => live.get(id) || { status: 'pending' },
    isPlaced: (id) => ['anchored', 'changed'].includes(live.get(id)?.status),
    groups() {
      const placed = [];
      const lost = [];
      for (const a of anns.values()) (EA.app.isPlaced(a.id) ? placed : lost).push(a);
      const ys = new Map(placed.map((a) => [a.id, pageY(a.id)]));
      placed.sort((a, b) => ys.get(a.id) - ys.get(b.id));
      return { placed, lost, orphans: lost.filter((a) => live.get(a.id)?.status === 'orphan').length };
    },
    anchorBox,
    createFromRange,
    patch,
    typeNote,
    flush,
    remove,
    setColor: (id, color) => patch(id, { color }),
    setActive,
    setHover,
    jumpTo,
    startPick,
    startReattach,
    togglePanel,
    updateSettings,
    sharePage,
    importFile: async (file) => importText(await file.text()),
    importText,
    openLibrary: () => api.runtime.sendMessage({ type: 'open-library' }),
    handleMessage,
  };

  picker = EA.createPicker(ui);
  notes = EA.createNotes(EA.app, ui);
  panel = EA.createPanel(EA.app, ui);
  selectionBar = EA.createSelectionBar(EA.app, ui);

  api.runtime.onMessage.addListener((message) => handleMessage(message));
  api.runtime.onConnect.addListener(onSidebarConnect);
  api.storage.onChanged.addListener(onStorageChange);

  // Esc closes the sidebar. Inside a note the first Esc just leaves the note.
  addEventListener('keydown', (e) => {
    if (shadow.querySelector('.ea-share-dialog[open]')) return;
    if (e.key !== 'Escape' || picker.active || isField(shadow.activeElement ?? host)) return;
    if (panelOpen) showInPagePanel(false);
    else if (sidebarPort) postToSidebar({ type: 'close' });
  }, true);

  document.addEventListener('click', onPageClick, true);
  document.addEventListener('contextmenu', (e) => (context = { target: e.target, x: e.clientX, y: e.clientY }), true);
  addEventListener('scroll', queueLayout, { capture: true, passive: true });
  addEventListener('resize', queueLayout);
  addEventListener('popstate', schedulePass);
  addEventListener('hashchange', schedulePass);
  // pushState navigations fire nothing a content script can hear.
  setInterval(checkUrl, 1000);

  // One write with no read first, so it still lands as the page goes away.
  addEventListener('pagehide', () => {
    if (!unsaved.size) return;
    unsaved.clear();
    api.storage.local.set({
      [EA.pageKey(url)]: { url, title: document.title, annotations: [...anns.values()], updatedAt: new Date().toISOString() },
    });
  });

  new MutationObserver(schedulePass).observe(document.documentElement, { childList: true, subtree: true, characterData: true });
  new ResizeObserver(queueLayout).observe(document.documentElement);

  EA.store.getSettings().then((saved) => {
    settings = saved;
    return load();
  });
})();
