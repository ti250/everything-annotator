// Small DOM helpers for the extension's own UI. Text only ever goes in through
// textContent, so notes from a shared file can't inject markup.
(() => {
  const EA = globalThis.EA;

  // Closed, so page scripts can't read your notes out of the DOM.
  EA.SHADOW_MODE = 'closed';

  EA.el = (tag, attrs = {}, ...children) => {
    const node = document.createElement(tag);
    for (const [key, value] of Object.entries(attrs)) {
      if (value === undefined || value === null || value === false) continue;
      if (key === 'class') node.className = value;
      else if (key === 'text') node.textContent = value;
      else if (key.startsWith('on')) node.addEventListener(key.slice(2), value);
      else if (key === 'vars') for (const [k, v] of Object.entries(value)) node.style.setProperty(k, v);
      else node.setAttribute(key, value === true ? '' : value);
    }
    node.append(...children.filter((c) => c !== null && c !== undefined));
    return node;
  };

  // Constructable sheets aren't subject to the page's CSP. Older Firefox can't
  // assign them from a content script, hence the <style> fallback.
  EA.applyStyles = (root, css) => {
    // Image URLs depend on the install, so they're filled in here.
    const url = (file) => `url("${EA.api.runtime.getURL(`assets/${file}.webp`)}")`;
    const textures = [
      'linen', 'linen-dark', 'tear', 'paper-cream', 'pin-red', 'pin-blue', 'pin-green', 'pin-white',
      ...EA.COLORS.map((c) => `paper-${c}`),
    ];
    css = `:host { ${textures.map((t) => `--tex-${t}: ${url(t)};`).join(' ')} }\n${css}`;
    try {
      const sheet = new CSSStyleSheet();
      sheet.replaceSync(css);
      root.adoptedStyleSheets = [sheet];
      if (root.adoptedStyleSheets.length === 1) return;
    } catch {}
    root.append(EA.el('style', { text: css }));
  };

  // field-sizing does this in CSS, but Safari before 26 doesn't have it.
  const nativeGrow = CSS.supports('field-sizing', 'content');
  EA.fitTextarea = (area) => {
    if (nativeGrow || !area.isConnected || !area.offsetParent) return; // unmeasurable while hidden
    area.style.height = 'auto';
    area.style.height = `${area.scrollHeight}px`;
  };

  // For after a render, when new or newly shown textareas can finally be measured.
  EA.fitAll = (parent) => {
    if (nativeGrow) return;
    for (const node of parent.eaNodes?.values() ?? []) EA.fitTextarea(node.eaArea);
  };

  // Updates `parent` to show `items`, reusing nodes so a textarea being typed in
  // keeps its focus and cursor.
  EA.syncList = (parent, items, keyOf, make, update) => {
    const nodes = (parent.eaNodes ||= new Map());
    const keep = new Set(items.map(keyOf));
    for (const [key, node] of nodes) {
      if (!keep.has(key)) {
        node.remove();
        nodes.delete(key);
      }
    }
    let cursor = parent.firstElementChild;
    for (const item of items) {
      const key = keyOf(item);
      let node = nodes.get(key);
      if (!node) {
        node = make(item);
        nodes.set(key, node);
      }
      update(node, item);
      if (node === cursor) cursor = cursor.nextElementSibling;
      else parent.insertBefore(node, cursor);
    }
  };

  // Each sticky gets its own patch of grain, pin and tear, chosen from its id so
  // it looks the same on every visit.
  EA.sheetVars = (id) => {
    let n = 7;
    for (const ch of id) n = (n * 131 + ch.charCodeAt(0)) % 1000003;
    const pins = ['red', 'blue', 'red', 'green', 'white'];
    return {
      '--px': `${n % 256}px`,
      '--py': `${(n >> 8) % 256}px`,
      '--pin': `var(--tex-pin-${pins[(n >> 3) % pins.length]})`,
      '--pin-x': `${36 + ((n >> 5) % 28)}%`,
      '--tear-x': `${(n >> 2) % 1024}px`,
    };
  };

  EA.shortDate = (iso) => new Date(iso).toLocaleDateString(undefined, { day: 'numeric', month: 'short', year: 'numeric' });

  EA.truncate = (text, max) => (text.length > max ? `${text.slice(0, max - 1).trimEnd()}…` : text);

  // What a note is attached to, in words.
  EA.describeTarget = (ann, max = 220) => {
    const a = ann.anchor;
    if (a.kind === 'text') return EA.truncate(a.exact, max);
    if (a.alt) return EA.truncate(`Image: ${a.alt}`, max);
    if (a.src) return EA.truncate(`Image: ${a.src.split('/').pop().split('?')[0]}`, max);
    return EA.truncate(a.text ? `<${a.tag}> ${a.text}` : `<${a.tag}> element`, max);
  };
})();
