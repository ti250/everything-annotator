// Stickies on the page itself.
//
// They live in a zero-size layer pinned to the document origin, so they scroll
// with the page natively and never lag behind it.
(() => {
  const EA = globalThis.EA;
  const { el } = EA;
  const WIDTH = 176;
  const FOLDED = 22;
  const GAP = 10;

  // A stable, very slight tilt per note, so a page of them doesn't look like a grid.
  const tiltOf = (id) => {
    let n = 0;
    for (const ch of id) n = (n * 31 + ch.charCodeAt(0)) % 997;
    return `${((n % 50) / 10 - 2.5).toFixed(1)}deg`;
  };

  EA.tiltOf = tiltOf;

  EA.colorDots = (app, ann) =>
    el(
      'div',
      { class: 'dots' },
      ...EA.COLORS.map((color) =>
        el('button', {
          class: `dot ${color}`,
          type: 'button',
          title: color,
          'aria-label': `Make this note ${color}`,
          onclick: () => app.setColor(ann.id, color),
        })
      )
    );

  EA.createNotes = (app, ui) => {
    const wall = el('div', { class: 'wall' });
    const thread = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    thread.setAttribute('class', 'thread');
    const threadPath = document.createElementNS('http://www.w3.org/2000/svg', 'path');
    thread.append(threadPath);
    ui.layer.append(thread, wall);

    function startDrag(e, ann, node) {
      if (e.button !== 0 || e.target.closest('button')) return;
      e.preventDefault();
      const { dx, dy } = ann.pos;
      const { clientX, clientY, pointerId } = e;
      node.setPointerCapture(pointerId);
      node.classList.add('lifted');
      const move = (m) => {
        ann.pos = { dx: dx + m.clientX - clientX, dy: dy + m.clientY - clientY };
        layout();
      };
      const up = () => {
        node.removeEventListener('pointermove', move);
        node.removeEventListener('pointerup', up);
        node.removeEventListener('pointercancel', up);
        node.classList.remove('lifted');
        app.patch(ann.id, { pos: ann.pos });
      };
      node.addEventListener('pointermove', move);
      node.addEventListener('pointerup', up);
      node.addEventListener('pointercancel', up);
    }

    function make(ann) {
      const area = el('textarea', {
        class: 'note-text',
        placeholder: 'Write something…',
        'aria-label': 'Note',
        spellcheck: 'true',
        oninput: () => {
          EA.fitTextarea(area);
          app.typeNote(ann.id, area.value);
        },
        onfocus: () => app.setActive(ann.id),
        onblur: () => app.flush(),
      });
      const fold = el('button', {
        class: 'icon-btn',
        type: 'button',
        title: 'Fold away',
        'aria-label': 'Fold note away',
        text: '–',
        onclick: () => app.patch(ann.id, { collapsed: true }),
      });
      const bin = el('button', {
        class: 'icon-btn',
        type: 'button',
        title: 'Throw away',
        'aria-label': 'Delete note',
        text: '×',
        onclick: () => {
          node.classList.add('crumple');
          setTimeout(() => app.remove(ann.id), 180);
        },
      });
      const tab = el('button', {
        class: 'fold-tab',
        type: 'button',
        title: 'Unfold note',
        'aria-label': 'Unfold note',
        onclick: () => app.patch(ann.id, { collapsed: false }),
      });
      const bar = el('div', { class: 'note-bar' }, EA.colorDots(app, ann), fold, bin);
      const node = el(
        'div',
        {
          class: 'note',
          vars: { '--tilt': tiltOf(ann.id), ...EA.sheetVars(ann.id) },
          onmouseenter: () => app.setHover(ann.id),
          onmouseleave: () => app.setHover(null),
        },
        el('div', { class: 'paper' }, bar, area),
        tab
      );
      node.eaArea = area;
      bar.addEventListener('pointerdown', (e) => startDrag(e, app.get(ann.id), node));
      return node;
    }

    function update(node, ann) {
      node.className = [
        'note',
        ann.color,
        ann.collapsed && 'folded',
        node.classList.contains('lifted') && 'lifted',
        app.activeId === ann.id && 'active',
      ].filter(Boolean).join(' ');
      if (node.eaArea.value !== ann.note && ui.focused() !== node.eaArea) {
        node.eaArea.value = ann.note;
        EA.fitTextarea(node.eaArea);
      }
    }

    function shouldShow(ann) {
      if (!app.settings.postits || !app.isPlaced(ann.id)) return false;
      return Boolean(ann.note.trim()) || app.activeId === ann.id || ui.focused() === wall.eaNodes?.get(ann.id)?.eaArea;
    }

    function sync() {
      EA.syncList(wall, app.annotations().filter(shouldShow), (a) => a.id, make, update);
      EA.fitAll(wall);
    }

    // The default spot: out in the margin beside the anchor if there's room,
    // otherwise as far right as the window allows.
    function homeFor(box, width, right) {
      const beside = box.block.right + 14;
      const x = beside + width <= right - 8 ? beside : Math.max(8, right - width - 12);
      return { x, y: box.first.top - 6 };
    }

    function drawThread(layerRect) {
      const id = app.hoverId || app.activeId;
      const node = id && wall.eaNodes?.get(id);
      const box = node && app.anchorBox(id);
      if (!box || node.classList.contains('folded')) {
        threadPath.removeAttribute('d');
        return;
      }
      const note = node.getBoundingClientRect();
      const fromX = box.first.right - layerRect.left;
      const fromY = box.first.top + box.first.height / 2 - layerRect.top;
      const toX = note.left + note.width / 2 - layerRect.left;
      const toY = note.top + 8 - layerRect.top;
      const sag = Math.min(40, Math.abs(toX - fromX) / 4) + 8;
      threadPath.setAttribute(
        'd',
        `M${fromX} ${fromY} Q${(fromX + toX) / 2} ${Math.max(fromY, toY) + sag} ${toX} ${toY}`
      );
    }

    function layout() {
      const nodes = wall.eaNodes;
      if (!nodes) return;
      const layerRect = ui.layer.getBoundingClientRect();
      const right = document.documentElement.clientWidth - (app.panelOpen ? EA.PANEL_WIDTH : 0);

      const placed = [];
      const wanted = [];
      for (const [id, node] of nodes) {
        const ann = app.get(id);
        const box = ann && app.anchorBox(id);
        node.classList.toggle('offstage', !box);
        if (!box) continue;
        const width = ann.collapsed ? FOLDED : WIDTH;
        const home = homeFor(box, width, right);
        wanted.push({ node, ann, width, height: node.offsetHeight, x: home.x, y: home.y });
      }
      wanted.sort((a, b) => a.y - b.y);

      // Notes you've dragged stay where you put them; the rest shuffle down to
      // avoid landing on top of each other.
      for (const n of wanted) {
        const moved = n.ann.pos.dx !== 0 || n.ann.pos.dy !== 0;
        if (moved) {
          n.x += n.ann.pos.dx;
          n.y += n.ann.pos.dy;
          placed.push(n);
        }
      }
      for (const n of wanted) {
        if (n.ann.pos.dx !== 0 || n.ann.pos.dy !== 0) continue;
        for (let clash = true; clash; ) {
          clash = false;
          for (const p of placed) {
            const overlapX = n.x < p.x + p.width && p.x < n.x + n.width;
            const overlapY = n.y < p.y + p.height + GAP && p.y < n.y + n.height + GAP;
            if (overlapX && overlapY) {
              n.y = p.y + p.height + GAP;
              clash = true;
            }
          }
        }
        placed.push(n);
      }
      for (const n of placed) {
        n.node.style.left = `${Math.round(n.x - layerRect.left)}px`;
        n.node.style.top = `${Math.round(n.y - layerRect.top)}px`;
      }
      drawThread(layerRect);
    }

    function focus(id) {
      sync();
      layout();
      const node = wall.eaNodes?.get(id);
      if (!node) return false;
      node.eaArea.focus({ preventScroll: true });
      return true;
    }

    return { sync, layout, focus };
  };
})();
