// The sidebar: every note for this page in reading order, a "came unstuck"
// section for ones that no longer match, and the file controls.
(() => {
  const EA = globalThis.EA;
  const { el } = EA;
  EA.PANEL_WIDTH = 348;

  // `docked` is the native browser sidebar: same sidebar, without the in-page
  // positioning or the tab on the page edge.
  EA.createPanel = (app, ui, { docked = false } = {}) => {
    const importInput = el('input', {
      type: 'file',
      accept: '.json,application/json',
      hidden: true,
      onchange: () => {
        const [file] = importInput.files;
        importInput.value = '';
        if (file) app.importFile(file);
      },
    });

    const postitSwitch = el('input', {
      type: 'checkbox',
      class: 'switch-input',
      onchange: () => app.updateSettings({ postits: postitSwitch.checked }),
    });
    const barSwitch = el('input', {
      type: 'checkbox',
      class: 'switch-input',
      onchange: () => app.updateSettings({ selectionBar: barSwitch.checked }),
    });
    const toggle = (input, label) => el('label', { class: 'switch' }, input, el('span', { class: 'switch-body' }), el('span', { text: label }));

    const placedTitle = el('h2', { class: 'section-title' });
    const placedList = el('div', { class: 'cards' });
    const empty = el(
      'div',
      { class: 'empty' },
      el('p', { text: 'No stickies on this page yet.' }),
      el('p', { text: 'Select text to highlight it, or use Add a sticky… for a sentence, word or image.' })
    );
    const lostTitle = el('h2', { class: 'section-title lost', text: 'Came unstuck' });
    const lostHelp = el('p', {
      class: 'lost-help',
      text: "This page has changed, and these notes can't find where they belong. Re-attach them, or throw them away.",
    });
    const lostList = el('div', { class: 'cards' });
    const lostSection = el('section', { hidden: true }, lostTitle, lostHelp, lostList);
    const share = el('button', { class: 'btn', type: 'button', text: 'Share annotations', onclick: () => app.sharePage() });

    const panel = el(
      'aside',
      { class: docked ? 'panel docked' : 'panel', hidden: true, 'aria-label': 'Everything Annotator' },
      // The browser's sidebar already has its own title and close button.
      docked
        ? null
        : el(
            'header',
            { class: 'panel-head' },
            el('div', { class: 'brand', text: 'Everything Annotator' }),
            el('button', {
              class: 'icon-btn close',
              type: 'button',
              title: 'Close',
              'aria-label': 'Close sidebar',
              text: '×',
              onclick: () => app.togglePanel(false),
            })
          ),
      el(
        'div',
        { class: 'controls' },
        el('button', { class: 'btn', type: 'button', text: 'Add a sticky…', onclick: () => app.startPick() }),
        toggle(postitSwitch, 'Stickies on the page'),
        toggle(barSwitch, 'Highlight toolbar on selection')
      ),
      el('div', { class: 'board' }, el('section', {}, placedTitle, empty, placedList), lostSection),
      el(
        'footer',
        { class: 'panel-foot' },
        share,
        el('button', { class: 'btn', type: 'button', text: 'Open file', onclick: () => importInput.click() }),
        el('button', { class: 'btn', type: 'button', text: 'All notes', onclick: () => app.openLibrary() }),
        importInput
      )
    );

    const dockCount = el('span', { class: 'dock-count' });
    const dockLost = el('span', { class: 'dock-lost', title: 'Some notes came unstuck', text: '!', hidden: true });
    const dock = el(
      'button',
      {
        class: 'dock',
        type: 'button',
        hidden: true,
        title: 'Open the sidebar',
        'aria-label': 'Open the sidebar',
        onclick: () => app.togglePanel(true),
      },
      dockCount,
      dockLost
    );
    ui.fixed.append(panel, dock);

    function makeCard(ann) {
      const area = el('textarea', {
        class: 'note-text',
        placeholder: 'Write something…',
        'aria-label': 'Note',
        oninput: () => {
          EA.fitTextarea(area);
          app.typeNote(ann.id, area.value);
        },
        onblur: () => app.flush(),
      });
      const quote = el('button', { class: 'quote', type: 'button', onclick: () => app.jumpTo(ann.id) });
      const status = el('p', { class: 'status' });
      const meta = el('span', { class: 'meta' });
      const reattach = el('button', {
        class: 'btn small',
        type: 'button',
        text: 'Re-attach',
        onclick: () => app.startReattach(ann.id),
      });
      const bin = el('button', {
        class: 'icon-btn',
        type: 'button',
        title: 'Throw away',
        'aria-label': 'Delete note',
        text: '×',
        onclick: () => {
          card.classList.add('crumple');
          setTimeout(() => app.remove(ann.id), 180);
        },
      });
      const card = el(
        'article',
        {
          class: 'card',
          vars: { '--tilt': EA.tiltOf(ann.id), ...EA.sheetVars(ann.id) },
          onmouseenter: () => app.setHover(ann.id),
          onmouseleave: () => app.setHover(null),
        },
        el(
          'div',
          { class: 'sheet' },
          quote,
          status,
          area,
          el('div', { class: 'card-foot' }, meta, EA.colorDots(app, ann), reattach, bin)
        ),
        el('span', { class: 'pin' })
      );
      Object.assign(card, { eaArea: area, eaQuote: quote, eaStatus: status, eaMeta: meta, eaReattach: reattach });
      return card;
    }

    function updateCard(card, ann) {
      const live = app.liveOf(ann.id);
      const lost = live.status === 'orphan' || live.status === 'pending';
      const hiddenOnPage = !lost && !app.anchorBox(ann.id);
      card.className = ['card', ann.color, lost && 'lost', app.activeId === ann.id && 'active', card.classList.contains('crumple') && 'crumple']
        .filter(Boolean)
        .join(' ');
      card.eaQuote.textContent = EA.describeTarget(ann);
      card.eaQuote.disabled = lost;
      card.eaMeta.textContent = EA.shortDate(ann.createdAt);
      card.eaReattach.hidden = live.status !== 'orphan';
      let status = '';
      if (live.status === 'pending') status = 'Looking for its spot…';
      else if (live.status === 'changed') status = `The text has changed. It now reads: “${EA.truncate(live.current, 120)}”`;
      else if (hiddenOnPage) status = "Its spot is hidden on the page right now.";
      card.eaStatus.textContent = status;
      card.eaStatus.hidden = !status;
      if (card.eaArea.value !== ann.note && ui.focused() !== card.eaArea) {
        card.eaArea.value = ann.note;
        EA.fitTextarea(card.eaArea);
      }
    }

    function sync() {
      const { placed, lost, orphans } = app.groups();
      const total = placed.length + lost.length;
      share.disabled = total === 0;
      postitSwitch.checked = app.settings.postits;
      barSwitch.checked = app.settings.selectionBar;
      panel.hidden = !app.panelOpen;
      dock.hidden = docked || app.panelOpen || total === 0;
      dockCount.textContent = String(total);
      dockLost.hidden = orphans === 0;
      placedTitle.textContent = `On this page (${placed.length})`;
      empty.hidden = total > 0;
      lostSection.hidden = lost.length === 0;
      const key = (a) => a.id;
      EA.syncList(placedList, placed, key, makeCard, updateCard);
      EA.syncList(lostList, lost, key, makeCard, updateCard);
      EA.fitAll(placedList);
      EA.fitAll(lostList);
    }

    function focus(id) {
      const card = placedList.eaNodes?.get(id) || lostList.eaNodes?.get(id);
      if (!card) return;
      card.scrollIntoView({ block: 'nearest' });
      card.eaArea.focus({ preventScroll: true });
    }

    function reveal(id) {
      (placedList.eaNodes?.get(id) || lostList.eaNodes?.get(id))?.scrollIntoView({ block: 'nearest' });
    }

    return { sync, focus, reveal };
  };
})();
