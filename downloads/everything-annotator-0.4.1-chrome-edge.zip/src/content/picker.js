// "Point at the thing you mean" mode, for sticking notes on things and for
// re-attaching notes that came unstuck. Over text it picks a sentence, which ↓
// narrows to a word and ↑ widens to the block. Dragging picks exact text.
(() => {
  const EA = globalThis.EA;
  const { el, anchoring } = EA;

  EA.createPicker = (ui) => {
    const box = el('div', { class: 'pick-box', hidden: true });
    const tag = el('div', { class: 'pick-tag' });
    box.append(tag);
    const lines = el('div');
    const message = el('span');
    const banner = el(
      'div',
      { class: 'banner', hidden: true },
      message,
      el('button', { class: 'banner-cancel', type: 'button', text: 'Cancel', onclick: () => stop() })
    );
    ui.fixed.append(box, lines, banner);

    let session = null;
    let point = null; // where the pointer is
    let hit = null; // the element under it
    let target = null; // { range, unit } or { element }
    let trail = []; // elements ↑ has climbed through
    let adjusted = null; // where the last ↑ or ↓ happened
    let textPicked = false;

    function draw() {
      lines.replaceChildren();
      box.hidden = true;
      if (target?.range) {
        for (const r of target.range.getClientRects()) {
          const line = el('div', { class: 'pick-rect' });
          Object.assign(line.style, { left: `${r.left}px`, top: `${r.top}px`, width: `${r.width}px`, height: `${r.height}px` });
          lines.append(line);
        }
      } else if (target?.element) {
        const r = target.element.getBoundingClientRect();
        box.hidden = false;
        Object.assign(box.style, { left: `${r.left}px`, top: `${r.top}px`, width: `${r.width}px`, height: `${r.height}px` });
        tag.textContent = `<${target.element.localName}>`;
      }
    }

    const textTarget = (unit) => {
      const range = point && anchoring.textUnitAt(point.x, point.y, unit);
      return range ? { range, unit } : null;
    };

    const elementTarget = () => ({ element: anchoring.promoteElement(hit) });

    const onMove = (e) => {
      if (e.buttons || ui.owns(e)) return;
      point = { x: e.clientX, y: e.clientY };
      // A size chosen with ↑ or ↓ survives a small nudge of the mouse.
      if (adjusted && Math.hypot(point.x - adjusted.x, point.y - adjusted.y) < 30) return;
      adjusted = null;
      const under = document.elementFromPoint(point.x, point.y);
      if (!under || under === document.documentElement || under === document.body || under === ui.host) {
        target = null;
        draw();
        return;
      }
      hit = under;
      trail = [];
      target = textTarget('sentence') || elementTarget();
      draw();
    };

    const onMouseUp = (e) => {
      if (ui.owns(e)) return;
      const sel = getSelection();
      if (sel.isCollapsed || !sel.toString().trim()) return;
      const range = sel.getRangeAt(0).cloneRange();
      const done = session.onPick;
      textPicked = true;
      stop();
      sel.removeAllRanges();
      done({ range });
    };

    const onClick = (e) => {
      if (ui.owns(e)) return;
      e.preventDefault();
      e.stopPropagation();
      if (!session || !target) return;
      const done = session.onPick;
      const picked = target.range ? { range: target.range.cloneRange() } : { element: target.element };
      stop();
      done(picked);
    };

    // The click that ends a text drag arrives after the picker has stopped, and
    // shouldn't follow a link the drag happened to finish on.
    const swallowClick = (e) => {
      if (!textPicked) return;
      textPicked = false;
      e.preventDefault();
      e.stopPropagation();
    };

    function grow() {
      if (target?.unit === 'word') target = textTarget('sentence') || target;
      else if (target?.unit === 'sentence') target = elementTarget();
      else if (target?.element?.parentElement && target.element.parentElement !== document.body) {
        trail.push(target.element);
        target = { element: target.element.parentElement };
      }
    }

    function shrink() {
      if (target?.unit === 'sentence') target = textTarget('word') || target;
      else if (trail.length) target = { element: trail.pop() };
      else if (target?.element) target = textTarget('sentence') || target;
    }

    const onKey = (e) => {
      if (e.key === 'Escape') {
        e.preventDefault();
        e.stopPropagation();
        stop();
      } else if ((e.key === 'ArrowUp' || e.key === 'ArrowDown') && target) {
        e.preventDefault();
        e.stopPropagation();
        (e.key === 'ArrowUp' ? grow : shrink)();
        adjusted = point;
        draw();
      }
    };

    function stop() {
      if (!session) return;
      session = null;
      target = null;
      hit = null;
      trail = [];
      adjusted = null;
      draw();
      banner.hidden = true;
      removeEventListener('mousemove', onMove, true);
      removeEventListener('mouseup', onMouseUp, true);
      removeEventListener('click', onClick, true);
      removeEventListener('keydown', onKey, true);
      setTimeout(() => {
        removeEventListener('click', swallowClick, true);
        textPicked = false;
      }, 50);
    }

    function start(options) {
      stop();
      session = options;
      message.textContent = options.label;
      banner.hidden = false;
      addEventListener('mousemove', onMove, true);
      addEventListener('mouseup', onMouseUp, true);
      addEventListener('click', onClick, true);
      addEventListener('click', swallowClick, true);
      addEventListener('keydown', onKey, true);
    }

    return { start, stop, get active() { return Boolean(session); } };
  };
})();
