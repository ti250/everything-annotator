// The tray of highlighters that appears over selected text.
(() => {
  const EA = globalThis.EA;
  const { el } = EA;

  EA.createSelectionBar = (app, ui) => {
    const hide = () => {
      bar.hidden = true;
    };

    // Read the selection now, not when the tray appeared: it may have grown since.
    const use = (color, withNote) => {
      const sel = getSelection();
      const selected = sel.rangeCount && !sel.isCollapsed ? sel.getRangeAt(0).cloneRange() : null;
      hide();
      sel.removeAllRanges();
      if (selected) app.createFromRange(selected, color, withNote);
    };

    const bar = el(
      'div',
      { class: 'pens', hidden: true, role: 'toolbar', 'aria-label': 'Highlight selection', onmousedown: (e) => e.preventDefault() },
      ...EA.COLORS.map((color) =>
        el('button', {
          class: `pen ${color}`,
          type: 'button',
          title: `Highlight ${color}`,
          'aria-label': `Highlight ${color}`,
          onclick: () => use(color, false),
        })
      ),
      el('button', {
        class: 'pen-note',
        type: 'button',
        title: 'Highlight and add a sticky',
        'aria-label': 'Highlight and add a sticky',
        onclick: () => use(app.settings.color, true),
      })
    );
    ui.layer.append(bar);

    function editable(node) {
      const element = node.nodeType === 1 ? node : node.parentElement;
      return !element || element.isContentEditable || Boolean(element.closest('input,textarea,select'));
    }

    function check() {
      const sel = getSelection();
      if (!app.settings.selectionBar || app.picking || !sel.rangeCount || sel.isCollapsed || !sel.toString().trim()) {
        hide();
        return;
      }
      const current = sel.getRangeAt(0);
      if (editable(current.commonAncestorContainer)) {
        hide();
        return;
      }
      const rects = current.getClientRects();
      if (!rects.length) return;
      bar.hidden = false;
      const layer = ui.layer.getBoundingClientRect();
      const box = current.getBoundingClientRect();
      const width = bar.offsetWidth;
      const height = bar.offsetHeight;
      const x = Math.min(Math.max(8, box.left + box.width / 2 - width / 2), document.documentElement.clientWidth - width - 8);
      const y = box.top - height - 10 < 8 ? box.bottom + 10 : box.top - height - 10;
      bar.style.left = `${x - layer.left}px`;
      bar.style.top = `${y - layer.top}px`;
    }

    let mouseDown = false;
    let settle = null;

    // Capture, so a page that stops these events can't hide the tray.
    addEventListener('mousedown', (e) => {
      if (!ui.owns(e)) mouseDown = true;
    }, true);
    addEventListener('mouseup', (e) => {
      mouseDown = false;
      if (!ui.owns(e)) setTimeout(check, 10);
    }, true);
    addEventListener('keyup', (e) => {
      if (e.key === 'Escape') hide();
    }, true);
    // Keyboard selection, including Vimium's visual mode, only shows up here.
    document.addEventListener('selectionchange', () => {
      if (getSelection().isCollapsed) return hide();
      clearTimeout(settle);
      settle = setTimeout(() => {
        if (!mouseDown) check();
      }, 200);
    });

    return { hide };
  };
})();
