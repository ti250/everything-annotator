// On-page and sidebar styling, in the clean skeuomorphic style of around 2011:
// linen, letterpress text, bevelled controls, and paper that lifts at the corners.
// Textures are small bundled tiles, and nothing here is fetched over the network.
(() => {
  globalThis.EA.UI_CSS = String.raw`
:host { all: initial; }
*, *::before, *::after { box-sizing: border-box; }
[hidden] { display: none !important; }

.layer, .fixed {
  --hand: "Noteworthy", "Bradley Hand", "Segoe Print", "Ink Free", "Comic Sans MS", cursive;
  --sans: "Helvetica Neue", Helvetica, Arial, sans-serif;
  --linen: var(--tex-linen);
  --linen-color: #e2dcd0;
  --ink: #3a3428;
  --muted: #736b5c;
  --press: 0 1px 0 rgba(255, 255, 255, .85);
  --bar: linear-gradient(#fbf9f4, #dcd6c9);
  --bar-edge: #a59c8b;
  --bar-shine: rgba(255, 255, 255, .9);
  --btn: linear-gradient(#fefdfb, #e5e0d5);
  --btn-down: linear-gradient(#d9d3c7, #e8e3d9);
  --btn-edge: #a9a091;
  --group: rgba(255, 255, 255, .66);
  --group-edge: rgba(90, 80, 60, .28);
  --accent-top: #eda24a;
  --accent-bottom: #c8741c;
  --danger: #a3271d;
  --note-ink: #38311f;
  font-family: var(--sans);
  color: var(--ink);
  -webkit-user-modify: read-only;
}
@media (prefers-color-scheme: dark) {
  .layer, .fixed {
    --linen: var(--tex-linen-dark);
    --linen-color: #3a3a3d;
    --ink: #f1f0ec;
    --muted: #bdbab2;
    --press: 0 -1px 0 rgba(0, 0, 0, .75);
    --bar: linear-gradient(#5a5a5e, #333336);
    --bar-edge: #151516;
    --bar-shine: rgba(255, 255, 255, .22);
    --btn: linear-gradient(#67676b, #434346);
    --btn-down: linear-gradient(#333336, #47474a);
    --btn-edge: #1a1a1b;
    --group: rgba(255, 255, 255, .07);
    --group-edge: rgba(0, 0, 0, .55);
    --danger: #f5a097;
  }
}
.layer { position: absolute; top: 0; left: 0; width: 0; height: 0; }
.fixed { position: fixed; top: 0; left: 0; width: 0; height: 0; }

.yellow { --paper: var(--tex-paper-yellow); --p: #fae470; }
.pink   { --paper: var(--tex-paper-pink);   --p: #fab0c4; }
.green  { --paper: var(--tex-paper-green);  --p: #bae69e; }
.blue   { --paper: var(--tex-paper-blue);   --p: #a8d8f0; }
.orange { --paper: var(--tex-paper-orange); --p: #fac484; }

button { font: inherit; color: inherit; cursor: pointer; }
:focus-visible { outline: 2px solid #4a90d9; outline-offset: 1px; }

.icon-btn {
  width: 20px; height: 20px; padding: 0; border: 0; border-radius: 4px;
  background: transparent; font: 700 14px/1 var(--sans); color: rgba(56, 49, 31, .6);
}
.icon-btn:hover { background: rgba(0, 0, 0, .09); color: var(--note-ink); }

.dots { display: flex; gap: 4px; }
.dot {
  width: 12px; height: 12px; padding: 0; border-radius: 50%; border: 1px solid rgba(0, 0, 0, .3);
  background: linear-gradient(rgba(255, 255, 255, .6), rgba(255, 255, 255, 0) 60%), var(--p);
}
.dot:hover { transform: scale(1.2); }
.card .dots, .card-foot > .icon-btn { opacity: 0; transition: opacity .12s; }
.card:hover .dots, .card:focus-within .dots, .card:hover .card-foot > .icon-btn, .card:focus-within .card-foot > .icon-btn { opacity: 1; }

/* ---- Stickies ---- */

/* The bottom corners lift: two soft shadows, angled apart and tucked behind the paper. */
.note::before, .note::after, .card::before, .card::after {
  content: ""; position: absolute; z-index: -1; bottom: 9px; width: 46%; height: 12px; pointer-events: none;
  box-shadow: 0 9px 8px rgba(0, 0, 0, .34);
}
.note::before, .card::before { left: 6px; transform: rotate(-2.6deg); }
.note::after, .card::after { right: 6px; transform: rotate(2.6deg); }

.note {
  position: absolute; width: 176px; pointer-events: auto;
  transform: rotate(calc(var(--tilt) * .4)); transition: transform .15s ease;
}
.note.active, .note:hover, .note:focus-within { transform: none; z-index: 5; }
.note.lifted { transform: scale(1.03); z-index: 6; }
.note.offstage { display: none; }

.paper, .sheet {
  position: relative; border-radius: 1px;
  background: linear-gradient(rgba(255, 255, 255, .3), rgba(255, 255, 255, 0) 38%, rgba(120, 90, 20, .07)), var(--p) var(--paper) var(--px) var(--py) / 256px;
  box-shadow: 0 0 1px rgba(0, 0, 0, .35), 0 1px 1px rgba(0, 0, 0, .14), inset 0 1px 0 rgba(255, 255, 255, .55);
}
.paper { padding: 0 10px 10px; }
.note-bar {
  position: relative; display: flex; align-items: center; justify-content: flex-end; gap: 2px;
  height: 22px; margin: 0 -10px; padding: 2px 4px 0; cursor: grab; touch-action: none;
}
.lifted .note-bar { cursor: grabbing; }
.note-bar .dots { margin-right: auto; padding-left: 6px; }
.note-bar > .dots, .note-bar > .icon-btn { opacity: 0; transition: opacity .12s; }
.note:hover .note-bar > .dots, .note:hover .note-bar > .icon-btn,
.note:focus-within .note-bar > .dots, .note:focus-within .note-bar > .icon-btn { opacity: 1; }
.note-text {
  display: block; width: 100%; min-height: 38px; max-height: 240px; padding: 0; margin: 0;
  border: 0; outline: 0; resize: none; overflow-y: auto; background: transparent;
  font: 14px/1.35 var(--hand); color: var(--note-ink); field-sizing: content;
}
.note-text::placeholder { color: rgba(56, 49, 31, .5); }

.fold-tab { display: none; }
.note.folded { width: 22px; }
.note.folded .paper, .note.folded::before, .note.folded::after { display: none; }
.note.folded .fold-tab {
  display: block; width: 22px; height: 22px; padding: 0; border: 0; border-radius: 1px;
  background: var(--p) var(--paper) 0 0 / 256px; box-shadow: 0 1px 2px rgba(0, 0, 0, .4);
}

.crumple { animation: dismiss .16s ease-in forwards; }
@keyframes dismiss { to { transform: scale(.94); opacity: 0; } }

.thread { position: absolute; top: 0; left: 0; width: 1px; height: 1px; overflow: visible; pointer-events: none; }
.thread path { fill: none; stroke: #c0392b; stroke-width: 1.25; opacity: .8; }

/* ---- Highlight toolbar, a dark glossy callout ---- */

.pens {
  position: absolute; display: flex; align-items: center; gap: 7px; padding: 6px 9px; border-radius: 9px;
  pointer-events: auto; border: 1px solid #111;
  background: linear-gradient(#55555a, #2a2a2d 50%, #1c1c1e 51%, #252527);
  box-shadow: inset 0 1px 0 rgba(255, 255, 255, .3), 0 4px 12px rgba(0, 0, 0, .42);
}
.pen {
  width: 20px; height: 20px; padding: 0; border-radius: 50%; border: 1px solid rgba(0, 0, 0, .6);
  background: linear-gradient(rgba(255, 255, 255, .62), rgba(255, 255, 255, 0) 55%), var(--p);
  box-shadow: 0 1px 0 rgba(255, 255, 255, .16); transition: transform .1s;
}
.pen:hover { transform: scale(1.14); }
.pen-note {
  width: 25px; height: 22px; padding: 0 0 0 6px; border: 0; border-left: 1px solid rgba(255, 255, 255, .22);
  background: none; color: #fff; font: 700 16px/1 var(--sans); text-shadow: 0 -1px 0 #000;
}
.pen-note::before { content: "+"; }
.pen-note:hover { color: #ffd79c; }

/* ---- Sidebar ---- */

.panel {
  position: fixed; top: 0; right: 0; bottom: 0; width: 348px; display: flex; flex-direction: column;
  background: var(--linen-color) var(--linen) 0 0 / 128px;
  border-left: 1px solid var(--bar-edge); box-shadow: -3px 0 14px rgba(0, 0, 0, .28);
  font: 13px/1.4 var(--sans);
}
.panel-head {
  display: flex; align-items: center; justify-content: space-between; height: 42px; padding: 0 10px 0 14px;
  background: var(--bar); border-bottom: 1px solid var(--bar-edge); box-shadow: inset 0 1px 0 var(--bar-shine), 0 1px 3px rgba(0, 0, 0, .2);
}
.brand { font-weight: 700; font-size: 14px; color: var(--ink); text-shadow: var(--press); }
.close { color: var(--muted); }
.close:hover { background: rgba(127, 127, 127, .2); color: var(--ink); }

.controls {
  display: flex; flex-direction: column; gap: 9px; margin: 12px 12px 2px; padding: 10px 12px;
  background: var(--group); border: 1px solid var(--group-edge); border-radius: 8px;
  box-shadow: inset 0 1px 0 var(--bar-shine), 0 1px 0 rgba(255, 255, 255, .2);
}
.panel-foot {
  display: flex; flex-wrap: wrap; gap: 6px; padding: 8px 12px;
  background: var(--bar); border-top: 1px solid var(--bar-edge); box-shadow: inset 0 1px 0 var(--bar-shine);
}

.btn {
  padding: 5px 10px; border: 1px solid var(--btn-edge); border-radius: 5px;
  font: 700 12px/1.3 var(--sans); color: var(--ink); text-shadow: var(--press); background: var(--btn);
  box-shadow: inset 0 1px 0 var(--bar-shine), 0 1px 1px rgba(0, 0, 0, .15);
}
.btn:hover { filter: brightness(1.04); }
.btn:active { background: var(--btn-down); box-shadow: inset 0 1px 3px rgba(0, 0, 0, .3); }
.btn:disabled { opacity: .55; cursor: default; }
.btn.small { padding: 2px 8px; font-size: 11px; color: #38311f; border-color: #a9a091; text-shadow: 0 1px 0 rgba(255, 255, 255, .8); background: linear-gradient(#fefdfb, #e5e0d5); box-shadow: inset 0 1px 0 #fff, 0 1px 1px rgba(0, 0, 0, .15); }

.switch { display: flex; align-items: center; justify-content: space-between; gap: 8px; font-size: 12px; font-weight: 700; color: var(--ink); text-shadow: var(--press); cursor: pointer; }
.switch-input { position: absolute; opacity: 0; }
.switch-body {
  order: 2; position: relative; flex: none; width: 44px; height: 22px; border-radius: 999px; border: 1px solid rgba(0, 0, 0, .4);
  background: linear-gradient(#c9c5bb, #e8e4db); box-shadow: inset 0 1px 3px rgba(0, 0, 0, .35), 0 1px 0 rgba(255, 255, 255, .5); transition: background .12s;
}
.switch-body::after {
  content: ""; position: absolute; top: -1px; left: -1px; width: 22px; height: 22px; border-radius: 50%; border: 1px solid rgba(0, 0, 0, .42);
  background: linear-gradient(#fff, #d6d2c9); box-shadow: inset 0 1px 0 #fff, 0 1px 2px rgba(0, 0, 0, .35); transition: left .12s;
}
.switch-input:checked + .switch-body { background: linear-gradient(var(--accent-bottom), var(--accent-top)); }
.switch-input:checked + .switch-body::after { left: 21px; }
.switch-input:focus-visible + .switch-body { outline: 2px solid #4a90d9; outline-offset: 1px; }

.board { flex: 1; overflow-y: auto; padding: 14px 12px; }

.section-title { margin: 0 0 12px 2px; font: 700 13px/1.4 var(--sans); color: var(--muted); text-shadow: var(--press); }
.section-title.lost { margin-top: 22px; color: var(--danger); }
.lost-help { margin: -6px 2px 14px; font-size: 12px; color: var(--muted); text-shadow: var(--press); }

.empty { padding: 24px 12px; font-size: 13px; text-align: center; color: var(--muted); text-shadow: var(--press); }
.empty p { margin: 0 0 6px; }
.empty p:first-child { font-weight: 700; font-size: 14px; }

.cards { display: flex; flex-direction: column; gap: 18px; }

.card { position: relative; transform: rotate(calc(var(--tilt) * .25)); transform-origin: var(--pin-x) 10px; transition: transform .12s; }
.card:hover, .card.active, .card:focus-within { transform: none; }
.sheet { padding: 16px 12px 6px; }
.card.active .sheet { outline: 2px solid #4a90d9; outline-offset: 1px; }
.card .note-text { min-height: 20px; }
.pin {
  position: absolute; top: -5px; left: var(--pin-x); width: 24px; height: 24px; margin-left: -10px; pointer-events: none;
  background: var(--pin) 0 0 / 100% 100%;
}
.quote {
  position: relative; display: block; width: 100%; margin: 0 0 13px; padding: 6px 8px 3px; border: 0; text-align: left;
  font: 12px/1.38 var(--sans); color: #4a4436; background: #f3ede0 var(--tex-paper-cream) var(--px) var(--py) / 256px;
  box-shadow: 0 -1px 1px rgba(0, 0, 0, .14); overflow-wrap: anywhere;
}
.quote::after {
  content: ""; position: absolute; left: 0; right: 0; top: calc(100% - 1px); height: 12px; pointer-events: none;
  background: var(--tex-tear) var(--tear-x) 0 / 512px 20px repeat-x;
}
.quote:not(:disabled):hover { color: #1f1b12; }
.quote:disabled { cursor: default; }
.status { margin: 0 0 6px; font: 11px/1.35 var(--sans); color: #7a3b10; overflow-wrap: anywhere; }
.card-foot { display: flex; align-items: center; gap: 7px; min-height: 22px; margin-top: 2px; }
.meta { margin-right: auto; font: 11px/1 var(--sans); color: rgba(56, 49, 31, .62); }

/* A sticky that's come loose hangs from one pin. */
.card.lost { transform: rotate(-1.6deg); transform-origin: 18px 10px; }
.card.lost:hover, .card.lost:focus-within { transform: rotate(-.5deg); }
.card.lost .pin { left: 8px; margin-left: 0; }

/* The page overlay deliberately has no size. In a native sidebar it is the
   containing block for the board, so it must fill the sidebar viewport. */
.fixed.sidebar-surface { width: 100%; height: 100%; }
.panel.docked { position: static; width: 100%; height: 100%; box-shadow: none; border-left: 0; }

/* ---- Dock, banner, picker, toasts ---- */

.dock {
  position: fixed; top: 38%; right: 0; display: flex; align-items: center; gap: 5px;
  height: 30px; padding: 0 9px 0 10px; pointer-events: auto;
  font: 700 12px/1 var(--sans); color: var(--ink); text-shadow: var(--press);
  background: var(--bar); border: 1px solid var(--bar-edge); border-right: 0; border-radius: 6px 0 0 6px;
  box-shadow: inset 0 1px 0 var(--bar-shine), -1px 1px 4px rgba(0, 0, 0, .3); transition: padding .1s;
}
.dock:hover { padding-right: 13px; }
.dock-lost {
  width: 14px; height: 14px; border-radius: 50%; font: 700 10px/14px var(--sans); text-align: center; text-shadow: none;
  color: #fff; background: linear-gradient(#ef6a5e, #b92c21); box-shadow: 0 1px 1px rgba(0, 0, 0, .35);
}

/* Banners and toasts are dark, translucent heads-up panels. */
.banner, .toast {
  font: 13px/1.35 var(--sans); color: #fff; text-shadow: 0 -1px 0 rgba(0, 0, 0, .6);
  background: rgba(28, 28, 30, .88); border: 1px solid rgba(255, 255, 255, .22); border-radius: 9px;
  box-shadow: inset 0 1px 0 rgba(255, 255, 255, .16), 0 4px 16px rgba(0, 0, 0, .4);
}
.banner {
  position: fixed; top: 12px; left: 50%; display: flex; align-items: center; gap: 12px; width: max-content; max-width: 90vw;
  padding: 5px 6px 5px 12px; transform: translateX(-50%); pointer-events: none;
}
/* Clicks pass through the banner, so what's under it can still be picked. */
.banner-cancel {
  pointer-events: auto; padding: 3px 9px; border: 1px solid #000; border-radius: 5px; font: 700 12px var(--sans); color: #fff;
  background: linear-gradient(#67676b, #38383b); box-shadow: inset 0 1px 0 rgba(255, 255, 255, .25);
}

.pick-box { position: fixed; pointer-events: none; border: 2px solid #c8741c; border-radius: 2px; background: rgba(245, 158, 11, .12); }
.pick-rect { position: fixed; pointer-events: none; background: rgba(245, 158, 11, .32); }
.pick-tag {
  position: absolute; left: -2px; top: -22px; padding: 2px 6px; border-radius: 3px; font: 11px/1.4 var(--sans); color: #fff; background: #c8741c; white-space: nowrap;
}

.toasts {
  position: fixed; left: 50%; bottom: 20px; display: flex; flex-direction: column; gap: 8px; align-items: center;
  width: max-content; max-width: 90vw; transform: translateX(-50%);
}
.toast { display: flex; align-items: center; gap: 10px; padding: 8px 12px; }
.toast-action { padding: 0; border: 0; background: none; font: 700 13px var(--sans); color: #ffc680; text-decoration: underline; }

@media (prefers-reduced-motion: reduce) {
  * { transition: none !important; animation-duration: 1ms !important; }
}
`;
})();
