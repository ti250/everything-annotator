// Every annotated page in one place, plus file import and backup.
(() => {
  const { EA } = globalThis;
  const $ = (id) => document.getElementById(id);
  const folders = $('folders');
  const message = $('message');
  const empty = $('empty');
  const search = $('search');
  const fileInput = $('file');

  const make = (tag, className, text) => {
    const node = document.createElement(tag);
    if (className) node.className = className;
    if (text !== undefined) node.textContent = text;
    return node;
  };

  function say(text) {
    message.textContent = text;
    message.hidden = false;
  }

  const hostOf = (url) => {
    try {
      return new URL(url).host || url;
    } catch {
      return url;
    }
  };

  const quoteOf = (a) => {
    const anchor = a.anchor;
    if (anchor.kind === 'text') return anchor.exact;
    return anchor.alt ? `Image: ${anchor.alt}` : anchor.text || `<${anchor.tag}> element`;
  };

  const short = (text, max) => (text.length > max ? `${text.slice(0, max - 1).trimEnd()}…` : text);

  function folderFor(page) {
    const folder = make('article', 'folder');
    const body = make('div', 'folder-body');
    body.append(make('h2', '', page.title || page.url), make('p', 'host', `${hostOf(page.url)} · ${page.annotations.length} note${page.annotations.length === 1 ? '' : 's'}`));

    const list = make('ul', 'note-list');
    for (const a of page.annotations) {
      const item = make('li', `note-item ${EA.COLORS.includes(a.color) ? a.color : 'yellow'}`);
      item.append(make('q', '', short(quoteOf(a), 200)));
      if (a.note.trim()) item.append(make('p', '', a.note));
      list.append(item);
    }

    const actions = make('div', 'folder-actions');
    if (EA.isOpenableUrl(page.url)) {
      const open = make('a', 'btn', 'Open page');
      open.href = page.url;
      open.target = '_blank';
      open.rel = 'noopener';
      actions.append(open);
    }
    const save = make('button', 'btn', 'Share annotations');
    save.type = 'button';
    save.onclick = () => EA.showShareDialog(document.body, page);
    const bin = make('button', 'btn danger', 'Throw away');
    bin.type = 'button';
    bin.onclick = async () => {
      if (!confirm(`Throw away all ${page.annotations.length} notes on "${page.title || page.url}"?`)) return;
      await EA.store.removePage(page.url);
    };
    actions.append(save, bin);

    body.append(list, actions);
    folder.append(body);
    return folder;
  }

  const matches = (page, term) =>
    !term ||
    [page.title, page.url, ...page.annotations.flatMap((a) => [a.note, quoteOf(a)])].some((t) => (t || '').toLowerCase().includes(term));

  async function render() {
    const pages = await EA.store.allPages();
    pages.sort((a, b) => (b.updatedAt || '').localeCompare(a.updatedAt || ''));
    const term = search.value.trim().toLowerCase();
    const shown = pages.filter((p) => matches(p, term));
    folders.replaceChildren(...shown.map(folderFor));
    empty.hidden = shown.length > 0;
    empty.textContent = pages.length
      ? 'Nothing matches that search.'
      : 'No notes yet. Highlight something on any web page and it will show up here. You can also drop a shared .annotations.json file on this page.';
    $('export-all').disabled = !pages.length;
  }

  async function importFile(file) {
    try {
      const pages = EA.parseFile(await file.text());
      const { added, updated } = await EA.store.importPages(pages);
      say(`Imported ${file.name}: ${added} new, ${updated} updated.`);
    } catch (error) {
      say(error.message);
    }
  }

  $('import').onclick = () => fileInput.click();
  fileInput.onchange = () => {
    const [file] = fileInput.files;
    fileInput.value = '';
    if (file) importFile(file);
  };
  $('export-all').onclick = async () => {
    const stamp = new Date().toISOString().slice(0, 10);
    EA.download(`everything-annotator-backup-${stamp}.json`, EA.buildLibraryFile(await EA.store.allPages()));
  };
  search.oninput = render;

  addEventListener('dragover', (e) => {
    e.preventDefault();
    document.body.classList.add('dropping');
  });
  addEventListener('dragleave', () => document.body.classList.remove('dropping'));
  addEventListener('drop', (e) => {
    e.preventDefault();
    document.body.classList.remove('dropping');
    const [file] = e.dataTransfer.files;
    if (file) importFile(file);
  });

  EA.api.storage.onChanged.addListener((changes, area) => {
    if (area === 'local' && Object.keys(changes).some((k) => k.startsWith('page:'))) render();
  });

  render();
})();
