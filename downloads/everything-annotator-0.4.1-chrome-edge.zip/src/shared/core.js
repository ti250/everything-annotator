// Shared by the content script and the library page: the file format, URL
// handling and storage. Everything here is plain data, no page DOM.
(() => {
  const EA = (globalThis.EA ||= {});

  // Firefox and Safari provide `browser`, Chrome only `chrome`.
  EA.api = globalThis.browser ?? globalThis.chrome;

  EA.COLORS = ['yellow', 'pink', 'green', 'blue', 'orange'];
  EA.FORMAT = 'everything-annotator';
  EA.FORMAT_VERSION = 1;
  EA.DEFAULT_SETTINGS = { postits: true, panelOpen: false, selectionBar: true, color: 'yellow' };

  EA.uid = () => {
    // crypto.randomUUID is missing on plain-http pages, getRandomValues is not.
    const b = crypto.getRandomValues(new Uint8Array(16));
    return [...b].map((x) => x.toString(16).padStart(2, '0')).join('');
  };

  // ---- URLs ---------------------------------------------------------------

  const TRACKING = /^(utm_\w+|fbclid|gclid|gbraid|wbraid|dclid|msclkid|yclid|mc_eid|mc_cid|igshid|mkt_tok|_hsenc|_hsmi|ref_src)$/i;

  // The identity of a page: same article, same notes, whichever link got you there.
  EA.pageUrl = (href) => {
    const u = new URL(href);
    // forEach, because these iterators can't be spread in a Firefox content script.
    const tracking = [];
    u.searchParams.forEach((_, key) => {
      if (TRACKING.test(key)) tracking.push(key);
    });
    for (const key of tracking) u.searchParams.delete(key);
    // #section links are the same page, but #/route and #!route are app routes.
    if (!/^#[/!]/.test(u.hash)) u.hash = '';
    return u.href;
  };

  EA.isOpenableUrl = (url) => {
    try {
      return ['http:', 'https:'].includes(new URL(url).protocol);
    } catch {
      return false;
    }
  };

  // ---- File format --------------------------------------------------------

  const str = (v, max) => (typeof v === 'string' ? v.slice(0, max) : '');
  const num = (v, min, max) => (Number.isFinite(v) ? Math.min(max, Math.max(min, v)) : 0);
  const date = (v) => (typeof v === 'string' && !Number.isNaN(Date.parse(v)) ? v : new Date().toISOString());

  function cleanAnchor(a) {
    if (!a || typeof a !== 'object') return null;
    if (a.kind === 'text') {
      const exact = str(a.exact, 50000);
      if (!exact) return null;
      return {
        kind: 'text',
        exact,
        prefix: str(a.prefix, 200),
        suffix: str(a.suffix, 200),
        start: num(a.start, 0, Number.MAX_SAFE_INTEGER),
      };
    }
    if (a.kind === 'element') {
      const selector = str(a.selector, 2000);
      if (!selector) return null;
      return {
        kind: 'element',
        selector,
        tag: str(a.tag, 40).toLowerCase(),
        text: str(a.text, 300),
        src: str(a.src, 1000),
        alt: str(a.alt, 300),
      };
    }
    return null;
  }

  // Files come from other people, so nothing in one is trusted. Unknown fields
  // are dropped here, and the UI only ever renders values through textContent.
  EA.cleanAnnotation = (a) => {
    if (!a || typeof a !== 'object') return null;
    const anchor = cleanAnchor(a.anchor);
    if (!anchor) return null;
    return {
      id: typeof a.id === 'string' && /^[\w-]{1,64}$/.test(a.id) ? a.id : EA.uid(),
      type: anchor.kind,
      color: EA.COLORS.includes(a.color) ? a.color : 'yellow',
      note: str(a.note, 20000),
      createdAt: date(a.createdAt),
      updatedAt: date(a.updatedAt),
      anchor,
      pos: { dx: num(a.pos?.dx, -5000, 5000), dy: num(a.pos?.dy, -5000, 5000) },
      collapsed: a.collapsed === true,
    };
  };

  function cleanPage(p) {
    if (!p || typeof p !== 'object' || typeof p.url !== 'string') return null;
    let url;
    try {
      const u = new URL(p.url);
      if (!['http:', 'https:', 'file:'].includes(u.protocol)) return null;
      url = EA.pageUrl(p.url);
    } catch {
      return null;
    }
    const list = Array.isArray(p.annotations) ? p.annotations.slice(0, 5000) : [];
    return { url, title: str(p.title, 500), annotations: list.map(EA.cleanAnnotation).filter(Boolean) };
  }

  // Accepts a one-page file or a whole-library backup. Throws a readable Error.
  EA.parseFile = (text) => {
    let data;
    try {
      data = JSON.parse(text);
    } catch {
      throw new Error("That file isn't valid JSON.");
    }
    if (data?.format !== EA.FORMAT) throw new Error("That isn't an Everything Annotator file.");
    if (!(data.version <= EA.FORMAT_VERSION)) {
      throw new Error('That file was made by a newer version of Everything Annotator.');
    }
    const raw = Array.isArray(data.pages) ? data.pages : [data];
    const pages = raw.map(cleanPage).filter((p) => p && p.annotations.length);
    if (!pages.length) throw new Error('No usable notes in that file.');
    return pages;
  };

  EA.buildPageFile = (page) => ({
    format: EA.FORMAT,
    version: EA.FORMAT_VERSION,
    exportedAt: new Date().toISOString(),
    url: page.url,
    title: page.title,
    annotations: page.annotations,
  });

  EA.buildLibraryFile = (pages) => ({
    format: EA.FORMAT,
    version: EA.FORMAT_VERSION,
    exportedAt: new Date().toISOString(),
    pages: pages.map(({ url, title, annotations }) => ({ url, title, annotations })),
  });

  EA.fileNameFor = (page) => {
    let host = '';
    try {
      host = new URL(page.url).hostname;
    } catch {}
    const base = (page.title || host || 'page')
      .toLowerCase()
      .replace(/[^\p{L}\p{N}]+/gu, '-')
      .replace(/^-+|-+$/g, '')
      .slice(0, 60);
    return `${base || 'page'}.annotations.json`;
  };

  EA.download = (name, data) => {
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = name;
    document.documentElement.append(a); // Firefox and Safari can ignore clicks on detached links
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(a.href), 10000);
  };

  // Newer edit wins, per annotation.
  EA.mergeAnnotations = (current, incoming) => {
    const byId = new Map(current.map((a) => [a.id, a]));
    let added = 0;
    let updated = 0;
    for (const a of incoming) {
      const mine = byId.get(a.id);
      if (!mine) added++;
      else if (Date.parse(a.updatedAt) > Date.parse(mine.updatedAt)) updated++;
      else continue;
      byId.set(a.id, a);
    }
    return { annotations: [...byId.values()], added, updated };
  };

  // ---- Storage ------------------------------------------------------------

  const local = () => EA.api.storage.local;
  const PREFIX = 'page:';
  EA.pageKey = (url) => PREFIX + url;

  // Writes are read-modify-write, so run them one at a time.
  let queue = Promise.resolve();
  const enqueue = (task) => {
    const run = queue.then(task, task);
    queue = run.catch(() => {});
    return run;
  };

  EA.store = {
    async getPage(url) {
      const key = EA.pageKey(url);
      return (await local().get(key))[key] || { url, title: '', annotations: [] };
    },

    async allPages() {
      const all = await local().get(null);
      return Object.entries(all)
        .filter(([k]) => k.startsWith(PREFIX))
        .map(([, v]) => v);
    },

    update(url, title, change) {
      return enqueue(async () => {
        const key = EA.pageKey(url);
        const page = (await local().get(key))[key] || { url, title: '', annotations: [] };
        const annotations = change(page.annotations);
        if (!annotations.length) return local().remove(key);
        await local().set({
          [key]: { url, title: title || page.title, annotations, updatedAt: new Date().toISOString() },
        });
      });
    },

    put(url, title, ann) {
      return this.update(url, title, (list) => {
        const i = list.findIndex((a) => a.id === ann.id);
        if (i < 0) return [...list, ann];
        const next = list.slice();
        next[i] = ann;
        return next;
      });
    },

    remove(url, title, id) {
      return this.update(url, title, (list) => list.filter((a) => a.id !== id));
    },

    removePage: (url) => enqueue(() => local().remove(EA.pageKey(url))),

    async importPages(pages) {
      let added = 0;
      let updated = 0;
      for (const p of pages) {
        await this.update(p.url, p.title, (list) => {
          const merged = EA.mergeAnnotations(list, p.annotations);
          added += merged.added;
          updated += merged.updated;
          return merged.annotations;
        });
      }
      return { added, updated };
    },

    async getSettings() {
      return { ...EA.DEFAULT_SETTINGS, ...(await local().get('settings')).settings };
    },

    setSettings: (settings) => local().set({ settings }),
  };
})();
