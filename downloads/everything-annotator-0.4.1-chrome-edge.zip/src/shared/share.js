// One sharing dialog for the in-page sidebar, native sidebar and library.
(() => {
  const { EA } = globalThis;
  const { el } = EA;
  const styled = new WeakSet();
  const css = `
.ea-share-dialog {
  --surface: linear-gradient(#fbf9f4, #ece7dc); --field: #fffdf8; --line: #a59c8b; --ink: #3a3428; --muted: #736b5c;
  --btn: linear-gradient(#fefdfb, #e5e0d5); --shine: rgba(255, 255, 255, .9); --press: 0 1px 0 rgba(255, 255, 255, .85);
  box-sizing: border-box; width: 460px; max-width: calc(100vw - 24px); max-height: calc(100vh - 32px);
  margin: auto; padding: 22px; border: 1px solid var(--line); border-radius: 10px; overflow: auto;
  color: var(--ink); background: var(--surface);
  font: 13px/1.5 "Helvetica Neue", Helvetica, Arial, sans-serif;
  box-shadow: inset 0 1px 0 var(--shine), 0 12px 40px #0007; pointer-events: auto; -webkit-user-modify: read-only;
}
@media (prefers-color-scheme: dark) {
  .ea-share-dialog {
    --surface: linear-gradient(#47474a, #2c2c2e); --field: #1f1f20; --line: #111; --ink: #f1f0ec; --muted: #bdbab2;
    --btn: linear-gradient(#67676b, #434346); --shine: rgba(255, 255, 255, .22); --press: 0 -1px 0 rgba(0, 0, 0, .75);
  }
}
.ea-share-dialog::backdrop { background: #0007; }
.ea-share-dialog * { box-sizing: border-box; }
.ea-share-dialog h2 { margin: 0 32px 14px 0; font-size: 16px; font-weight: 700; line-height: 1.3; text-shadow: var(--press); }
.ea-share-dialog p { margin: 8px 0; }
.ea-share-dialog .share-title { font-weight: 700; overflow-wrap: anywhere; }
.ea-share-dialog .share-url { font-size: 12px; color: var(--muted); overflow-wrap: anywhere; }
.ea-share-dialog .share-count { margin: 12px 0 16px; }
.ea-share-dialog .share-actions { display: flex; flex-wrap: wrap; gap: 8px; margin: 16px 0; }
.ea-share-dialog button {
  padding: 6px 12px; border: 1px solid var(--line); border-radius: 5px; background: var(--btn);
  color: var(--ink); font: 700 12px/1.4 "Helvetica Neue", Helvetica, Arial, sans-serif; text-shadow: var(--press); cursor: pointer;
  box-shadow: inset 0 1px 0 var(--shine), 0 1px 1px rgba(0, 0, 0, .15);
}
.ea-share-dialog button:hover { filter: brightness(1.04); }
.ea-share-dialog button:disabled { opacity: .6; cursor: wait; }
.ea-share-dialog .share-save {
  color: #fff; text-shadow: 0 -1px 0 rgba(0, 0, 0, .35); border-color: #9a5712;
  background: linear-gradient(#eda24a, #c8741c); box-shadow: inset 0 1px 0 rgba(255, 255, 255, .4), 0 1px 1px rgba(0, 0, 0, .2);
}
.ea-share-dialog .share-close { position: absolute; top: 12px; right: 12px; padding: 0 8px; border: 0; background: none; box-shadow: none; font-size: 18px; color: var(--muted); }
.ea-share-dialog .share-help { padding-top: 14px; border-top: 1px solid var(--line); color: var(--muted); }
.ea-share-dialog .share-help strong { display: block; margin-bottom: 4px; color: var(--ink); font-weight: 700; }
.ea-share-dialog .share-status { min-height: 20px; font-weight: 700; }
.ea-share-dialog details { margin-top: 12px; }
.ea-share-dialog summary { cursor: pointer; }
.ea-share-dialog textarea {
  display: block; width: 100%; height: 140px; margin-top: 8px; padding: 8px; resize: vertical;
  border: 1px solid var(--line); border-radius: 5px; background: var(--field); color: var(--ink);
  font: 12px/1.4 monospace; user-select: text; box-shadow: inset 0 1px 2px rgba(0, 0, 0, .2);
}
.ea-share-dialog :focus-visible { outline: 2px solid #4a90d9; outline-offset: 2px; }
`;

  EA.showShareDialog = (parent, page) => {
    const root = parent.getRootNode();
    if (root.querySelector('.ea-share-dialog[open]')) return;
    if (!styled.has(root)) {
      try {
        const sheet = new CSSStyleSheet();
        sheet.replaceSync(css);
        root.adoptedStyleSheets = [...root.adoptedStyleSheets, sheet];
      } catch {
        (root.head || root).append(el('style', { text: css }));
      }
      styled.add(root);
    }

    // Freeze the bundle now, so tab changes and incoming edits cannot change what
    // is shared after the user has reviewed its title, URL and annotation count.
    const text = JSON.stringify(EA.buildPageFile(page), null, 2);
    const bundle = JSON.parse(text);
    const name = EA.fileNameFor(bundle);
    const previous = root.activeElement;
    const status = el('p', { class: 'share-status', role: 'status', 'aria-live': 'polite' });
    const area = el('textarea', { readonly: true, spellcheck: 'false', 'aria-label': 'Annotations bundle' });
    area.value = text;
    const details = el('details', {}, el('summary', { text: 'View or manually copy the bundle' }), area);
    const save = el('button', {
      type: 'button', class: 'share-save', text: 'Save annotation file', autofocus: true,
      onclick: () => {
        try {
          EA.download(name, bundle);
          status.textContent = 'Download started. Attach the saved file to an email or message.';
        } catch {
          status.textContent = 'The download could not start. Try copying the bundle instead.';
        }
      },
    });
    const copy = el('button', {
      type: 'button', class: 'share-copy', text: 'Copy bundle',
      onclick: async () => {
        try {
          await navigator.clipboard.writeText(text);
          status.textContent = 'Bundle copied. Paste it into a plain-text file ending in .annotations.json.';
        } catch {
          details.open = true;
          area.focus();
          area.select();
          status.textContent = 'Copy the selected bundle with ⌘C or Ctrl+C, then save it as a .annotations.json file.';
        }
      },
    });
    const actions = el('div', { class: 'share-actions' }, save, copy);
    const file = new File([text], name, { type: 'application/json' });
    let canShare = false;
    try { canShare = !!navigator.share && !!navigator.canShare?.({ files: [file] }); } catch {}
    if (canShare) {
      const share = el('button', {
        type: 'button', class: 'share-system', text: 'Share with…',
        onclick: async () => {
          share.disabled = true;
          try {
            await navigator.share({ files: [file], title: bundle.title || 'Annotations' });
            status.textContent = 'Bundle handed to your sharing app.';
          } catch (error) {
            status.textContent = error.name === 'AbortError'
              ? 'Sharing cancelled. Your annotations are unchanged.'
              : 'Sharing is unavailable here. Save the file or copy the bundle instead.';
          } finally {
            share.disabled = false;
          }
        },
      });
      actions.append(share);
    }

    const id = `ea-share-${EA.uid()}`;
    const count = bundle.annotations.length;
    const dialog = el('dialog', { class: 'ea-share-dialog', 'aria-labelledby': id },
      el('h2', { id, text: 'Share annotations' }),
      el('button', { type: 'button', class: 'share-close', 'aria-label': 'Close sharing dialog', text: '×', onclick: () => dialog.close() }),
      el('p', { class: 'share-title', text: bundle.title || 'Untitled page' }),
      el('p', { class: 'share-url', text: bundle.url }),
      el('p', { class: 'share-count', text: `${count} annotation${count === 1 ? '' : 's'}, including highlights and notes, bundled with this page’s URL.` }),
      actions,
      el('p', { class: 'share-help' },
        el('strong', { text: 'How to open a shared file' }),
        'Install Everything Annotator, choose Open file in the sidebar or in All notes, then visit the included URL. The annotations will appear on the page.'),
      el('p', { text: 'Only this page’s annotations are included. Nothing is uploaded by Everything Annotator.' }),
      details, status);

    dialog.addEventListener('keydown', (event) => {
      event.stopPropagation();
      if (event.key === 'Tab') {
        const fields = [...dialog.querySelectorAll('button:not(:disabled), summary, textarea')]
          .filter((node) => node.getClientRects().length && (node !== area || details.open));
        const first = fields[0];
        const last = fields.at(-1);
        if (event.shiftKey && root.activeElement === first) {
          event.preventDefault();
          last.focus();
        } else if (!event.shiftKey && root.activeElement === last) {
          event.preventDefault();
          first.focus();
        }
      }
      if (event.key === 'Escape') {
        event.preventDefault();
        dialog.close();
      }
    });
    dialog.addEventListener('click', (event) => {
      if (event.target !== dialog) return;
      const box = dialog.getBoundingClientRect();
      if (event.clientX < box.left || event.clientX > box.right || event.clientY < box.top || event.clientY > box.bottom) dialog.close();
    });
    dialog.addEventListener('close', () => {
      dialog.remove();
      if (previous?.isConnected) previous.focus({ preventScroll: true });
    }, { once: true });
    parent.append(dialog);
    dialog.showModal();
  };
})();
