// The browser's native sidebar. It draws the same sidebar as the in-page panel,
// but the notes belong to the content script in the active tab, so this page
// mirrors that tab's state and sends every change back over a port.
(() => {
  const { EA } = globalThis;
  const { api, el } = EA;

  const root = document.getElementById('root');
  const shadow = root.attachShadow({ mode: 'open' });
  EA.applyStyles(shadow, EA.UI_CSS);
  const fixed = el('div', { class: 'fixed sidebar-surface' });
  shadow.append(fixed);

  const ui = { fixed, focused: () => shadow.activeElement };

  let port = null;
  let tabId = null;
  let windowId = null;
  let state = null;
  let settings = { ...EA.DEFAULT_SETTINGS };

  // Firefox ignores window.close() in a sidebar.
  const closeSidebar = () => (api.sidebarAction ? api.sidebarAction.close() : window.close());

  const item = (id) => state?.items.find((i) => i.ann.id === id);
  const send = (action, ...args) => port?.postMessage({ action, args });

  const app = {
    get settings() { return settings; },
    panelOpen: true,
    get activeId() { return state?.activeId ?? null; },
    groups() {
      const pick = (ids) => (ids || []).map((id) => item(id)?.ann).filter(Boolean);
      const lost = pick(state?.lost);
      return {
        placed: pick(state?.placed),
        lost,
        orphans: lost.filter((a) => item(a.id).status === 'orphan').length,
      };
    },
    liveOf: (id) => {
      const i = item(id);
      return i ? { status: i.status, current: i.current } : { status: 'pending' };
    },
    anchorBox: (id) => (item(id)?.hidden ? null : {}),
    typeNote(id, text) {
      const i = item(id);
      if (i) Object.assign(i.ann, { note: text, updatedAt: new Date().toISOString() });
      send('typeNote', id, text);
    },
    flush: () => send('flush'),
    remove: (id) => send('remove', id),
    setColor: (id, color) => send('setColor', id, color),
    setHover: (id) => send('setHover', id),
    jumpTo: (id) => send('jumpTo', id),
    startPick: () => send('startPick'),
    startReattach: (id) => send('startReattach', id),
    togglePanel: closeSidebar,
    updateSettings(change) {
      settings = { ...settings, ...change };
      EA.store.setSettings(settings);
      panel.sync();
    },
    sharePage() {
      if (!state?.items.length) return;
      send('flush');
      const page = { url: state.url, title: state.title, annotations: state.items.map((i) => i.ann) };
      EA.showShareDialog(fixed, page);
    },
    importFile: async (file) => send('importText', await file.text()),
    openLibrary: () => api.runtime.sendMessage({ type: 'open-library' }),
  };

  const panel = EA.createPanel(app, ui, { docked: true });

  function attach() {
    port?.disconnect();
    port = null;
    state = null;
    panel.sync();
    if (tabId === null) return;
    const mine = api.tabs.connect(tabId, { name: 'ea-sidebar' });
    port = mine;
    mine.onMessage.addListener((message) => {
      if (message.type === 'state') {
        state = message.state;
        panel.sync();
      } else if (message.type === 'focus') {
        panel.focus(message.id);
      } else if (message.type === 'close') {
        closeSidebar();
      }
    });
    mine.onDisconnect.addListener(() => {
      void api.runtime.lastError; // nothing to attach to on pages like chrome://
      if (port !== mine) return;
      port = null;
      state = null;
      panel.sync();
    });
  }

  async function follow() {
    const [tab] = await api.tabs.query({ active: true, currentWindow: true });
    tabId = tab?.id ?? null;
    windowId = tab?.windowId ?? windowId;
    attach();
  }

  // Esc closes the sidebar. Inside a note the first Esc just leaves the note.
  addEventListener('keydown', (e) => {
    if (shadow.querySelector('.ea-share-dialog[open]')) return;
    if (e.key !== 'Escape') return;
    const field = shadow.activeElement;
    if (field?.matches('textarea')) field.blur();
    else closeSidebar();
  });

  api.tabs.onActivated.addListener((info) => {
    if (info.windowId !== windowId) return;
    tabId = info.tabId;
    attach();
  });
  api.tabs.onUpdated.addListener((id, change) => {
    if (id === tabId && change.status === 'complete') attach();
  });
  api.storage.onChanged.addListener((changes, area) => {
    if (area === 'local' && changes.settings?.newValue) {
      settings = { ...settings, ...changes.settings.newValue };
      panel.sync();
    }
  });

  // Lets the background script know this sidebar is open, so the toolbar button can
  // close it. The port drops whenever that script is put to sleep, so reconnect.
  function announce() {
    const host = api.runtime.connect({ name: 'ea-sidebar-open' });
    host.postMessage({ windowId });
    host.onMessage.addListener((message) => {
      if (message.type === 'close') closeSidebar();
    });
    host.onDisconnect.addListener(() => setTimeout(announce, 100));
  }

  EA.store.getSettings().then((saved) => {
    settings = saved;
    return follow();
  }).then(announce);
})();
